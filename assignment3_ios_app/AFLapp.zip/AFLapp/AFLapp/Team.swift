//
//  Team.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 19/5/2025.
//


// Updated Team struct to include points
struct Team: Comparable {
    let name: String
    let goals: Int
    let behinds: Int
    let score: Int
    let points: Int // Points from wins/draws/losses

    // Comparable conformance for sorting: sort by points, then by score
    static func < (lhs: Team, rhs: Team) -> Bool {
        if lhs.points != rhs.points {
            return lhs.points > rhs.points // Sort by points descending
        }
        return lhs.score > rhs.score // If points are equal, sort by score descending
    }
}
