//
//  ComparePlayersViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 19/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class ComparePlayersViewController: UIViewController {
    
    @IBOutlet weak var addPlayer1: UIImageView!
    @IBOutlet weak var player1name: UILabel!
    @IBOutlet weak var player1Number: UILabel!
    @IBOutlet weak var player1Age: UILabel!
    @IBOutlet weak var player1Height: UILabel!
    @IBOutlet weak var player1Kicks: UILabel!
    @IBOutlet weak var player1Handballs: UILabel!
    @IBOutlet weak var player1Disposals: UILabel!
    @IBOutlet weak var player1Marks: UILabel!
    @IBOutlet weak var player1Tackles: UILabel!
    @IBOutlet weak var player1Goals: UILabel!
    @IBOutlet weak var player1Behinds: UILabel!
    @IBOutlet weak var player1Score: UILabel!
    
    
    @IBOutlet weak var addPlayer2: UIImageView!
    
    @IBOutlet weak var player2name: UILabel!
    @IBOutlet weak var player2Number: UILabel!
    @IBOutlet weak var player2Age: UILabel!
    @IBOutlet weak var player2Height: UILabel!
    @IBOutlet weak var player2Handballs: UILabel!
    @IBOutlet weak var player2Kicks: UILabel!
    @IBOutlet weak var player2Disposals: UILabel!
    @IBOutlet weak var player2Mark: UILabel!
    @IBOutlet weak var playr2Tackels: UILabel!
    @IBOutlet weak var player2Goals: UILabel!
    @IBOutlet weak var player2Behinds: UILabel!
    @IBOutlet weak var player2Score: UILabel!
    

        
    var currentMatchId: String?
    private var selectedPlayer1: Player?
    private var selectedPlayer2: Player?
    private var team1Players: [Player] = []
    private var team2Players: [Player] = []
    private var playerStatsDict: [String: PlayerStats] = [:] // Map player number to stats
    private let db = Firestore.firestore()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Add tap gestures to player image views to trigger player selection
        let tapPlayer1 = UITapGestureRecognizer(target: self, action: #selector(addPlayer1Tapped))
        addPlayer1.isUserInteractionEnabled = true
        addPlayer1.addGestureRecognizer(tapPlayer1)
        
        let tapPlayer2 = UITapGestureRecognizer(target: self, action: #selector(addPlayer2Tapped))
        addPlayer2.isUserInteractionEnabled = true
        addPlayer2.addGestureRecognizer(tapPlayer2)
        
        // Fetch players for both teams
        fetchTeamPlayers()
    }
    
    @objc func addPlayer1Tapped() {
        popupTeamPlayerList(forPlayer: 1)
    }
    
    @objc func addPlayer2Tapped() {
        popupTeamPlayerList(forPlayer: 2)
    }
    
    // MARK: - Fetch Team Players
    func fetchTeamPlayers() {
        guard let matchId = currentMatchId else {
            showAlert(message: "Invalid match ID.")
            return
        }
        
        let group = DispatchGroup()
        
        // Fetch team1 players
        group.enter()
        db.collection("match").document(matchId).collection("team1players").getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching team1 players: \(error)")
                self.showAlert(message: "Failed to load team1 players.")
            } else if let snapshot = snapshot {
                self.team1Players = snapshot.documents.compactMap { doc in
                    let data = doc.data()
                    return Player(
                        documentID: doc.documentID,
                        name: data["name"] as? String ?? "",
                        number: data["number"] as? String ?? "",
                        position: data["position"] as? String ?? "",
                        team: data["team"] as? String ?? "Team 1",
                        age: data["age"] as? String ?? "",
                        height: data["height"] as? String ?? "",
                        imageBase64: data["imageBase64"] as? String
                    )
                }
                print("Fetched \(self.team1Players.count) team1 players")
            }
            group.leave()
        }
        
        // Fetch team2 players
        group.enter()
        db.collection("match").document(matchId).collection("team2players").getDocuments { (snapshot, error) in
            if let error = error {
                print("Error fetching team2 players: \(error)")
                self.showAlert(message: "Failed to load team2 players.")
            } else if let snapshot = snapshot {
                self.team2Players = snapshot.documents.compactMap { doc in
                    let data = doc.data()
                    return Player(
                        documentID: doc.documentID,
                        name: data["name"] as? String ?? "",
                        number: data["number"] as? String ?? "",
                        position: data["position"] as? String ?? "",
                        team: data["team"] as? String ?? "Team 2",
                        age: data["age"] as? String ?? "",
                        height: data["height"] as? String ?? "",
                        imageBase64: data["imageBase64"] as? String
                    )
                }
                print("Fetched \(self.team2Players.count) team2 players")
            }
            group.leave()
        }
        
        // After fetching players, fetch their stats
        group.notify(queue: .main) {
            self.fetchPlayerStats()
        }
    }
    
    // MARK: - Fetch Player Stats
    func fetchPlayerStats() {
        guard let matchId = currentMatchId else {
            showAlert(message: "Invalid match ID.")
            return
        }
        
        let types = ["Goal", "Behind", "Kick", "Handball", "Mark", "Tackle"]
        var results: [String: [QueryDocumentSnapshot]] = [:]
        let group = DispatchGroup()
        
        // Fetch actions for each type
        for type in types {
            group.enter()
            db.collection("match").document(matchId).collection("actions")
                .whereField("action", isEqualTo: type)
                .getDocuments { (snapshot, error) in
                    if let error = error {
                        print("Error fetching \(type): \(error)")
                        self.showAlert(message: "Failed to load \(type) stats.")
                    } else if let snapshot = snapshot {
                        print("Fetched \(snapshot.documents.count) \(type) actions")
                        results[type] = snapshot.documents
                    }
                    group.leave()
                }
        }
        
        group.notify(queue: .main) {
            // Initialize stats dictionary
            self.playerStatsDict = [:]
            
            
            // Process each action type
            for type in types {
                let documents = results[type] ?? []
                for doc in documents {
                    guard let number = doc.data()["playerNumber"] as? String,
                          let playerName = doc.data()["playerName"] as? String else {
                        print("Missing or invalid playerNumber or playerName in document: \(doc.data())")
                        continue
                    }
                    
                    // Initialize PlayerStats if not already present
                    if self.playerStatsDict[number] == nil {
                        self.playerStatsDict[number] = PlayerStats(
                            number: number,
                            name: playerName,
                            goals: 0,
                            behinds: 0,
                            kicks: 0,
                            handballs: 0,
                            marks: 0,
                            tackles: 0
                        )
                    }
                    
                    // Update stats
                    var stats = self.playerStatsDict[number]!
                    switch type {
                    case "Goal": stats.goals += 1
                    case "Behind": stats.behinds += 1
                    case "Kick": stats.kicks += 1
                    case "Handball": stats.handballs += 1
                    case "Mark": stats.marks += 1
                    case "Tackle": stats.tackles += 1
                    default: break
                    }
                    self.playerStatsDict[number] = stats
                }
            }
            
            // If players are already selected, update their display
            if let player1 = self.selectedPlayer1 {
                self.displayPlayer1(player: player1, stats: self.playerStatsDict[player1.number])
            }
            if let player2 = self.selectedPlayer2 {
                self.displayPlayer2(player: player2, stats: self.playerStatsDict[player2.number])
            }
        }
    }
    
    // MARK: - Popup Team Player List
    func popupTeamPlayerList(forPlayer playerNumber: Int) {
        let alert = UIAlertController(title: "Select Player \(playerNumber)", message: nil, preferredStyle: .actionSheet)
        
        // Add team1 players
        for player in team1Players {
            alert.addAction(UIAlertAction(title: "\(player.name) (#\(player.number)) - \(player.team)", style: .default, handler: { _ in
                if playerNumber == 1 {
                    self.selectedPlayer1 = player
                    self.displayPlayer1(player: player, stats: self.playerStatsDict[player.number])
                } else {
                    self.selectedPlayer2 = player
                    self.displayPlayer2(player: player, stats: self.playerStatsDict[player.number])
                }
            }))
        }
        
        // Add team2 players
        for player in team2Players {
            alert.addAction(UIAlertAction(title: "\(player.name) (#\(player.number)) - \(player.team)", style: .default, handler: { _ in
                if playerNumber == 1 {
                    self.selectedPlayer1 = player
                    self.displayPlayer1(player: player, stats: self.playerStatsDict[player.number])
                } else {
                    self.selectedPlayer2 = player
                    self.displayPlayer2(player: player, stats: self.playerStatsDict[player.number])
                }
            }))
        }
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
    // MARK: - Display Player 1
    func displayPlayer1(player: Player, stats: PlayerStats?) {
        player1name.text = player.name
        player1Number.text = player.number
        player1Age.text = player.age.isEmpty ? "N/A" : player.age
        player1Height.text = player.height.isEmpty ? "N/A" : player.height
        
        // Display stats if available, otherwise show zeros
        if let stats = stats {
            player1Kicks.text = "\(stats.kicks)"
            player1Handballs.text = "\(stats.handballs)"
            player1Disposals.text = "\(stats.kicks + stats.handballs)"
            player1Marks.text = "\(stats.marks)"
            player1Tackles.text = "\(stats.tackles)"
            player1Goals.text = "\(stats.goals)"
            player1Behinds.text = "\(stats.behinds)"
            player1Score.text = "\(stats.goals * 6 + stats.behinds)"
        } else {
            player1Kicks.text = "0"
            player1Handballs.text = "0"
            player1Disposals.text = "0"
            player1Marks.text = "0"
            player1Tackles.text = "0"
            player1Goals.text = "0"
            player1Behinds.text = "0"
            player1Score.text = "0"
        }
        
        // Display player image if available
        if let base64 = player.imageBase64 {
                print("Player 1 imageBase64 length: \(base64.count)")
                if let data = Data(base64Encoded: base64, options: .ignoreUnknownCharacters) {
                    print("Player 1 Base64 decoded, data length: \(data.count)")
                    addPlayer1.image = UIImage(data: data)
                } else {
                    print("Player 1 Base64 decoding failed")
                    addPlayer1.image = UIImage(named: "defaultPlayer")
                }
            } else {
                print("Player 1 imageBase64 is nil")
                addPlayer1.image = UIImage(named: "defaultPlayer")
            }
    }
    
    // MARK: - Display Player 2
    func displayPlayer2(player: Player, stats: PlayerStats?) {
        player2name.text = player.name
        player2Number.text = player.number
        player2Age.text = player.age.isEmpty ? "N/A" : player.age
        player2Height.text = player.height.isEmpty ? "N/A" : player.height
        
        // Display stats if available, otherwise show zeros
        if let stats = stats {
            player2Kicks.text = "\(stats.kicks)"
            player2Handballs.text = "\(stats.handballs)"
            player2Disposals.text = "\(stats.kicks + stats.handballs)"
            player2Mark.text = "\(stats.marks)"
            playr2Tackels.text = "\(stats.tackles)"
            player2Goals.text = "\(stats.goals)"
            player2Behinds.text = "\(stats.behinds)"
            player2Score.text = "\(stats.goals * 6 + stats.behinds)"
        } else {
            player2Kicks.text = "0"
            player2Handballs.text = "0"
            player2Disposals.text = "0"
            player2Mark.text = "0"
            playr2Tackels.text = "0"
            player2Goals.text = "0"
            player2Behinds.text = "0"
            player2Score.text = "0"
        }
        
        // Display player image if available
        if let base64 = player.imageBase64 {
                print("Player 2 imageBase64 length: \(base64.count)")
                if let data = Data(base64Encoded: base64, options: .ignoreUnknownCharacters) {
                    print("Player 2 Base64 decoded, data length: \(data.count)")
                    addPlayer2.image = UIImage(data: data)
                } else {
                    print("Player 2 Base64 decoding failed")
                    addPlayer2.image = UIImage(named: "defaultPlayer")
                }
            } else {
                print("Player 2 imageBase64 is nil")
                addPlayer2.image = UIImage(named: "defaultPlayer")
            }
    }
    
    // MARK: - Show Alert
    func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
}
