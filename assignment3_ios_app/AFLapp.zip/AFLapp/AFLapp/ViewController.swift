//
//  ViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 2/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class ViewController: UIViewController {
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }
    @IBAction func btnCreateMatch(Sender:UIButton)
    {
        
    }
    
    @IBAction func btnRecordMatch(_ sender: UIButton) {
        
        let db = Firestore.firestore()
        // Fetch the most recent match
        db.collection("match")
            .order(by: "timestamp", descending: true) // Sort by timestamp, most recent first
            .limit(to: 1) // Get only the most recent match
            .getDocuments { [weak self] (snapshot, error) in
                guard let self = self else { return }
                
                if let error = error {
                    print("Error fetching recent match: \(error)")
                    self.showErrorAlert(message: "Failed to fetch recent match.")
                    return
                }
                
                guard let document = snapshot?.documents.first else {
                    self.showErrorAlert(message: "No matches found.")
                    return
                }
                
                // Get the match ID
                let currentMatchId = document.documentID
                print("Current Match ID: \(currentMatchId)")
                
                // Perform the segue and pass the matchId
                DispatchQueue.main.async {
                    self.performSegue(withIdentifier: "toRecordPage", sender: currentMatchId)
                }
            }
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        print("Preparing segue")
        if segue.identifier == "toRecordPage",
           let destinationVC = segue.destination as? RecordViewController,
           let currentMatchId = sender as? String {
            destinationVC.currentMatchId = currentMatchId
            print("Passing Match ID: \(currentMatchId) to RecordViewController")
        }
    }
    // Helper method to show error alerts
    private func showErrorAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
    

}
