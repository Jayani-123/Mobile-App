//
//  PlayerDetailsViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 7/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class PlayerDetailsViewController: UIViewController, UIPickerViewDataSource,UITextFieldDelegate,UIPickerViewDelegate,UIImagePickerControllerDelegate,UINavigationControllerDelegate {
    
    
    @IBOutlet weak var playerImage: UIImageView!
    
    @IBOutlet weak var enterPlayerName: UITextField!
    @IBOutlet weak var number: UITextField!
    @IBOutlet weak var position: UITextField!
    @IBOutlet weak var team: UITextField!
    
    @IBOutlet weak var age: UITextField!
    
    @IBOutlet weak var height: UITextField!
    
    // Dropdown options
        let playerNumbers = Array(1...50).map { String($0) }
        let positions = ["Forward", "Midfield", "Defender", "Goalkeeper", "Ruck"]
        let ages = Array(18...40).map { String($0) }
        let heights = Array(150...210).map { "\($0) cm" }
        var teamNames: [String] = []
        
        var playerToEdit: Player?
        var playerTeam: String?
        
        var selectedPlayerNumber: String?
        var selectedPosition: String?
        var selectedAge: String?
        var selectedHeight: String?
        var selectedTeam: String?
        var selectedImage: UIImage?
        
        let imagePicker = UIImagePickerController()
        var playersArray: [Player] = []
        var pickerView = UIPickerView()
        var toolBar = UIToolbar()
        var matchDocumentID: String?
        private var isTeamNamesLoaded = false
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Disable team field until team names are loaded
            team.isEnabled = false
            team.placeholder = "Loading teams..."
            loadTeamNames()
            setupPickerViews()
            
            imagePicker.delegate = self
            imagePicker.allowsEditing = true
            
            // Image tap gesture
            playerImage.isUserInteractionEnabled = true
            let tapGesture = UITapGestureRecognizer(target: self, action: #selector(selectImage))
            playerImage.addGestureRecognizer(tapGesture)
            
            // Populate fields if editing a player
            if let player = playerToEdit {
                populateFieldsForEditing(player)
            } else {
                // Set placeholders for text fields
                enterPlayerName.placeholder = "Enter player name"
                number.placeholder = "Select number"
                position.placeholder = "Select position"
                age.placeholder = "Select age"
                height.placeholder = "Select height"
            }
        }
        
        private func loadTeamNames() {
            guard let matchID = matchDocumentID else {
                showAlert(message: "No match ID provided")
                team.placeholder = "Select team"
                team.isEnabled = true
                return
            }
            let db = Firestore.firestore()
            db.collection("match").document(matchID).getDocument { [weak self] (document, error) in
                guard let self = self else { return }
                if let error = error {
                    print("Error loading team names: \(error.localizedDescription)")
                    self.showAlert(message: "Error loading team names")
                    self.teamNames = ["Team 1", "Team 2"] // Fallback
                } else if let document = document, document.exists {
                    self.teamNames = [
                        document.get("team1") as? String ?? "Team 1",
                        document.get("team2") as? String ?? "Team 2"
                    ]
                } else {
                    self.teamNames = ["Team 1", "Team 2"] // Fallback
                }
                DispatchQueue.main.async {
                    self.isTeamNamesLoaded = true
                    self.team.isEnabled = true
                    self.team.placeholder = "Select team"
                    self.pickerView.reloadAllComponents()
                }
            }
        }
        
        func populateFieldsForEditing(_ player: Player) {
            enterPlayerName.text = player.name
            selectedPlayerNumber = player.number
            selectedPosition = player.position
            selectedTeam = player.team
            selectedAge = player.age
            selectedHeight = player.height
            
            number.text = selectedPlayerNumber
            position.text = selectedPosition
            team.text = selectedTeam
            age.text = selectedAge
            height.text = selectedHeight
            
            if let base64String = player.imageBase64, let image = base64ToImage(base64String) {
                playerImage.image = image
                selectedImage = image
            }
        }
        
        @objc func selectImage() {
            let alert = UIAlertController(title: "Choose Image", message: nil, preferredStyle: .actionSheet)
            alert.addAction(UIAlertAction(title: "Gallery", style: .default, handler: { _ in self.openGallery() }))
            alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
            present(alert, animated: true, completion: nil)
        }
        
        func openGallery() {
            imagePicker.sourceType = .photoLibrary
            present(imagePicker, animated: true)
        }
        
        @objc func donePicker() {
            // Capture the currently displayed picker value
            if number.isFirstResponder, !playerNumbers.isEmpty {
                let row = pickerView.selectedRow(inComponent: 0)
                selectedPlayerNumber = playerNumbers[row]
                number.text = selectedPlayerNumber
            } else if position.isFirstResponder, !positions.isEmpty {
                let row = pickerView.selectedRow(inComponent: 0)
                selectedPosition = positions[row]
                position.text = selectedPosition
            } else if age.isFirstResponder, !ages.isEmpty {
                let row = pickerView.selectedRow(inComponent: 0)
                selectedAge = ages[row]
                age.text = selectedAge
            } else if height.isFirstResponder, !heights.isEmpty {
                let row = pickerView.selectedRow(inComponent: 0)
                selectedHeight = heights[row]
                height.text = selectedHeight
            } else if team.isFirstResponder, !teamNames.isEmpty {
                let row = pickerView.selectedRow(inComponent: 0)
                selectedTeam = teamNames[row]
                team.text = selectedTeam
            }
            view.endEditing(true)
        }
        
        @objc func cancelPicker() {
            if number.isFirstResponder {
                selectedPlayerNumber = nil
                number.text = ""
            } else if position.isFirstResponder {
                selectedPosition = nil
                position.text = ""
            } else if age.isFirstResponder {
                selectedAge = nil
                age.text = ""
            } else if height.isFirstResponder {
                selectedHeight = nil
                height.text = ""
            } else if team.isFirstResponder {
                selectedTeam = nil
                team.text = ""
            }
            view.endEditing(true)
        }
        
        // MARK: - UIPickerViewDataSource & Delegate
        func numberOfComponents(in pickerView: UIPickerView) -> Int {
            return 1
        }
        
        func pickerView(_ pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
            switch true {
            case number.isFirstResponder:
                return playerNumbers.count
            case position.isFirstResponder:
                return positions.count
            case age.isFirstResponder:
                return ages.count
            case height.isFirstResponder:
                return heights.count
            case team.isFirstResponder:
                return teamNames.count
            default:
                return 0
            }
        }
        
        func pickerView(_ pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
            switch true {
            case number.isFirstResponder:
                return row < playerNumbers.count ? playerNumbers[row] : nil
            case position.isFirstResponder:
                return row < positions.count ? positions[row] : nil
            case age.isFirstResponder:
                return row < ages.count ? ages[row] : nil
            case height.isFirstResponder:
                return row < heights.count ? heights[row] : nil
            case team.isFirstResponder:
                return row < teamNames.count ? teamNames[row] : nil
            default:
                return nil
            }
        }
        
        func pickerView(_ pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
            switch true {
            case number.isFirstResponder where row < playerNumbers.count:
                selectedPlayerNumber = playerNumbers[row]
                number.text = selectedPlayerNumber
            case position.isFirstResponder where row < positions.count:
                selectedPosition = positions[row]
                position.text = selectedPosition
            case age.isFirstResponder where row < ages.count:
                selectedAge = ages[row]
                age.text = selectedAge
            case height.isFirstResponder where row < heights.count:
                selectedHeight = heights[row]
                height.text = selectedHeight
            case team.isFirstResponder where row < teamNames.count:
                selectedTeam = teamNames[row]
                team.text = selectedTeam
            default:
                break
            }
        }
        
        // MARK: - UITextFieldDelegate
        func textFieldDidBeginEditing(_ textField: UITextField) {
            if textField == team, !isTeamNamesLoaded {
                showAlert(message: "Team names are still loading. Please try again.")
                textField.resignFirstResponder()
                return
            }
            // Set picker selection and update selected value if none exists
            if textField == number, !playerNumbers.isEmpty {
                let index = selectedPlayerNumber != nil ? playerNumbers.firstIndex(of: selectedPlayerNumber!) ?? 0 : 0
                pickerView.selectRow(index, inComponent: 0, animated: false)
                if selectedPlayerNumber == nil {
                    selectedPlayerNumber = playerNumbers[index]
                    number.text = selectedPlayerNumber
                }
            } else if textField == position, !positions.isEmpty {
                let index = selectedPosition != nil ? positions.firstIndex(of: selectedPosition!) ?? 0 : 0
                pickerView.selectRow(index, inComponent: 0, animated: false)
                if selectedPosition == nil {
                    selectedPosition = positions[index]
                    position.text = selectedPosition
                }
            } else if textField == age, !ages.isEmpty {
                let index = selectedAge != nil ? ages.firstIndex(of: selectedAge!) ?? 0 : 0
                pickerView.selectRow(index, inComponent: 0, animated: false)
                if selectedAge == nil {
                    selectedAge = ages[index]
                    age.text = selectedAge
                }
            } else if textField == height, !heights.isEmpty {
                let index = selectedHeight != nil ? heights.firstIndex(of: selectedHeight!) ?? 0 : 0
                pickerView.selectRow(index, inComponent: 0, animated: false)
                if selectedHeight == nil {
                    selectedHeight = heights[index]
                    height.text = selectedHeight
                }
            } else if textField == team, !teamNames.isEmpty {
                let index = selectedTeam != nil ? teamNames.firstIndex(of: selectedTeam!) ?? 0 : 0
                pickerView.selectRow(index, inComponent: 0, animated: false)
                if selectedTeam == nil {
                    selectedTeam = teamNames[index]
                    team.text = selectedTeam
                }
            }
        }
        
        func setupPickerViews() {
            pickerView.delegate = self
            pickerView.dataSource = self
            
            // Assign input views
            number.inputView = pickerView
            position.inputView = pickerView
            age.inputView = pickerView
            height.inputView = pickerView
            team.inputView = pickerView
            
            // Toolbar with Done and Cancel buttons
            toolBar.barStyle = .default
            toolBar.isTranslucent = true
            toolBar.sizeToFit()
            
            let doneButton = UIBarButtonItem(title: "Done", style: .done, target: self, action: #selector(donePicker))
            let cancelButton = UIBarButtonItem(title: "Cancel", style: .plain, target: self, action: #selector(cancelPicker))
            let spaceButton = UIBarButtonItem(barButtonSystemItem: .flexibleSpace, target: nil, action: nil)
            toolBar.setItems([cancelButton, spaceButton, doneButton], animated: false)
            toolBar.isUserInteractionEnabled = true
            
            number.inputAccessoryView = toolBar
            position.inputAccessoryView = toolBar
            age.inputAccessoryView = toolBar
            height.inputAccessoryView = toolBar
            team.inputAccessoryView = toolBar
            
            // Set text field delegates
            enterPlayerName.delegate = self
            number.delegate = self
            position.delegate = self
            age.delegate = self
            height.delegate = self
            team.delegate = self
        }
        
        // MARK: - UIImagePickerControllerDelegate
        func imagePickerController(_ picker: UIImagePickerController, didFinishPickingMediaWithInfo info: [UIImagePickerController.InfoKey : Any]) {
            if let pickedImage = (info[.editedImage] as? UIImage) ?? (info[.originalImage] as? UIImage) {
                selectedImage = pickedImage
                playerImage.image = pickedImage
            }
            dismiss(animated: true)
        }
        
        func imagePickerControllerDidCancel(_ picker: UIImagePickerController) {
            dismiss(animated: true)
        }
        
    @IBAction func saveButtonTapped(_ sender: UIButton) {
        // Validate all required fields
               guard let name = enterPlayerName.text, !name.isEmpty else {
                   showAlert(message: "Please enter a player name.")
                   return
               }
               guard let number = selectedPlayerNumber else {
                   showAlert(message: "Please select a player number.")
                   return
               }
               guard let position = selectedPosition else {
                   showAlert(message: "Please select a position.")
                   return
               }
               guard let team = selectedTeam else {
                   showAlert(message: "Please select a team.")
                   return
               }
               guard let age = selectedAge else {
                   showAlert(message: "Please select an age.")
                   return
               }
               guard let height = selectedHeight else {
                   showAlert(message: "Please select a height.")
                   return
               }
               guard let matchID = matchDocumentID else {
                   showAlert(message: "No match selected. Please try again.")
                   return
               }
               guard let image = selectedImage else {
                   showAlert(message: "Please select an image for the player.")
                   return
               }
               
               // Check if a player with the same number already exists
               checkPlayerNumberExists(number: number, team: team, matchID: matchID, currentDocumentID: playerToEdit?.documentID) { exists, error in
                   if let error = error {
                       self.showAlert(message: "Error checking player number: \(error.localizedDescription)")
                       return
                   }
                   
                   if exists {
                       self.showAlert(message: "A player with number \(number) already exists in this team.")
                       return
                   }
                   
                   // Convert image to Base64
                   let resizedImage = self.resizeImage(image, targetSize: CGSize(width: 200, height: 200)) ?? image
                   let imageBase64 = self.convertImageToBase64(image: resizedImage)
                   if imageBase64.isEmpty {
                       self.showAlert(message: "Failed to convert image to Base64.")
                       return
                   }
                   
                   // Create Player object
                   let player = Player(
                       documentID: self.playerToEdit?.documentID,
                       name: name,
                       number: number,
                       position: position,
                       team: team,
                       age: age,
                       height: height,
                       imageBase64: imageBase64
                   )
                   
                   // Save or update player in Firestore
                   if let playerToEdit = self.playerToEdit, let docID = playerToEdit.documentID, let teamCollection = self.playerTeam {
                       self.updatePlayer(player, documentID: docID, teamCollection: teamCollection, matchID: matchID)
                   } else {
                       self.savePlayer(player, toTeam: team, matchID: matchID)
                   }
               }
           }
           
           func updatePlayer(_ player: Player, documentID: String, teamCollection: String, matchID: String) {
               let db = Firestore.firestore()
               let matchRef = db.collection("match").document(matchID)
               
               do {
                   try matchRef.collection(teamCollection).document(documentID).setData(from: player) { error in
                       if let error = error {
                           print("Error updating player: \(error.localizedDescription)")
                           self.showAlert(message: "Failed to update player.")
                       } else {
                           print("Player updated in \(teamCollection) subcollection.")
                           self.showAlert(message: "Player updated successfully!") {
                               self.navigationController?.popViewController(animated: true)
                           }
                           self.clearFields()
                       }
                   }
               } catch {
                   print("Encoding error: \(error.localizedDescription)")
                   self.showAlert(message: "Encoding error occurred.")
               }
           }
           
           func checkPlayerNumberExists(number: String, team: String, matchID: String, currentDocumentID: String?, completion: @escaping (Bool, Error?) -> Void) {
               let db = Firestore.firestore()
               let matchRef = db.collection("match").document(matchID)
               let subcollection = teamNames.firstIndex(of: team) == 0 ? "team1players" : "team2players"
               
               matchRef.collection(subcollection)
                   .whereField("number", isEqualTo: number)
                   .getDocuments { (snapshot, error) in
                       if let error = error {
                           completion(false, error)
                           return
                       }
                       
                       if let documents = snapshot?.documents {
                           let exists = documents.contains { doc in
                               let docID = doc.documentID
                               return currentDocumentID == nil || docID != currentDocumentID
                           }
                           completion(exists, nil)
                       } else {
                           completion(false, nil)
                       }
                   }
           }
           
           func savePlayer(_ player: Player, toTeam team: String, matchID: String) {
               let db = Firestore.firestore()
               let matchRef = db.collection("match").document(matchID)
               let subcollection = teamNames.firstIndex(of: team) == 0 ? "team1players" : "team2players"
               
               do {
                   try matchRef.collection(subcollection).addDocument(from: player) { error in
                       if let error = error {
                           print("Error saving player: \(error.localizedDescription)")
                           self.showAlert(message: "Failed to save player.")
                       } else {
                           print("Player saved to \(subcollection) subcollection.")
                           self.showAlert(message: "Player saved successfully!") {
                               if let nav = self.navigationController {
                                   nav.popViewController(animated: true)
                               } else {
                                   self.dismiss(animated: true, completion: nil)
                               }
                           }
                           self.clearFields()
                       }
                   }
               } catch {
                   print("Encoding error: \(error.localizedDescription)")
                   self.showAlert(message: "Encoding error occurred.")
               }
           }
           
           func convertImageToBase64(image: UIImage) -> String {
               guard let imageData = image.jpegData(compressionQuality: 0.5) else {
                   print("Failed to convert image to JPEG data")
                   return ""
               }
               let base64String = imageData.base64EncodedString()
               print("Base64 string generated, length: \(base64String.count)")
               return base64String
           }
           
           func showAlert(message: String, completion: (() -> Void)? = nil) {
               let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
               alert.addAction(UIAlertAction(title: "OK", style: .default) { _ in
                   completion?()
               })
               present(alert, animated: true)
           }
           
           func displayPlayerImage(_ player: Player, in imageView: UIImageView) {
               if let base64String = player.imageBase64,
                  let image = base64ToImage(base64String) {
                   imageView.image = image
               } else {
                   imageView.image = nil // Or set a placeholder image
               }
           }
           
           func base64ToImage(_ base64String: String) -> UIImage? {
               if let imageData = Data(base64Encoded: base64String, options: .ignoreUnknownCharacters) {
                   return UIImage(data: imageData)
               }
               return nil
           }
           
           func resizeImage(_ image: UIImage, targetSize: CGSize) -> UIImage? {
               let size = image.size
               let widthRatio = targetSize.width / size.width
               let heightRatio = targetSize.height / size.height
               let newSize = CGSize(width: size.width * min(widthRatio, heightRatio),
                                    height: size.height * min(widthRatio, heightRatio))
               
               UIGraphicsBeginImageContextWithOptions(newSize, false, 1.0)
               image.draw(in: CGRect(origin: .zero, size: newSize))
               let newImage = UIGraphicsGetImageFromCurrentImageContext()
               UIGraphicsEndImageContext()
               return newImage
           }
           
           func clearFields() {
               enterPlayerName.text = ""
               number.text = ""
               position.text = ""
               team.text = ""
               age.text = ""
               height.text = ""
               
               selectedPlayerNumber = nil
               selectedPosition = nil
               selectedAge = nil
               selectedHeight = nil
               selectedTeam = nil
               selectedImage = nil
               playerImage.image = nil // Clear the image view
           }
       }
