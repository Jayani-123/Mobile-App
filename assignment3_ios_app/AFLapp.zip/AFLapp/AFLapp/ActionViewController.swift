//
//  ActionViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 14/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class ActionViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet weak var actionTableView: UITableView!
    

        
        var actions: [MatchAction] = []
        var currentMatchId: String?
        var team1Name: String?
        var team2Name: String?
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            actionTableView.delegate = self
            actionTableView.dataSource = self
            actionTableView.isScrollEnabled = true
            
            guard currentMatchId != nil else {
                print("Error: matchId is nil")
                showErrorAlert(message: "No match ID provided.")
                return
            }
            
            // Fetch team names before fetching actions
            fetchTeamNames()
        }
        
        // MARK: - Share Actions
        @IBAction func shareActionsTapped(_ sender: UIBarButtonItem) {
            guard !actions.isEmpty else {
                showErrorAlert(message: "No actions available to share.")
                return
            }
            
            guard let csvURL = generateCSVFile() else {
                return // Error already handled in generateCSVFile
            }
            
            let activityVC = UIActivityViewController(activityItems: [csvURL], applicationActivities: nil)
            activityVC.completionWithItemsHandler = { _, _, _, error in
                if let error = error {
                    print("Error sharing CSV: \(error)")
                    self.showErrorAlert(message: "Failed to share CSV file.")
                }
                // Clean up temporary file
                try? FileManager.default.removeItem(at: csvURL)
            }
            
            // For iPad compatibility
            activityVC.popoverPresentationController?.barButtonItem = sender
            present(activityVC, animated: true)
        }
        
        // MARK: - Generate CSV File
    private func generateCSVFile() -> URL? {
        // Define CSV headers
        let headers = ["Team", "Quarter", "Time", "Action", "Player Number", "Player Name", "Player ID", "Timestamp"]
        
        // Create CSV rows
        var csvText = headers.joined(separator: ",") + "\n"
        
        for action in actions {
            // Safely unwrap optional teamName
            let team = "\(action.teamName) "
            
            // Non-optional fields
            let quarter = "\(action.quarter)"
            let time = action.quarterTime
            let actionType = action.action
            let playerNumber = action.playerNumber
            let playerName = action.playerName
            let timestamp = action.timestamp.description // Convert Date to String
            
            // Escape commas and quotes
            let escapedTeam = "\"\(team.replacingOccurrences(of: "\"", with: "\"\""))\""
            let escapedTime = "\"\(time.replacingOccurrences(of: "\"", with: "\"\""))\""
            let escapedAction = "\"\(actionType.replacingOccurrences(of: "\"", with: "\"\""))\""
            let escapedPlayerNumber = "\"\(playerNumber.replacingOccurrences(of: "\"", with: "\"\""))\""
            let escapedPlayerName = "\"\(playerName.replacingOccurrences(of: "\"", with: "\"\""))\""
            let escapedTimestamp = "\"\(timestamp.replacingOccurrences(of: "\"", with: "\"\""))\""
            
            let row = [escapedTeam, quarter, escapedTime, escapedAction, escapedPlayerNumber, escapedPlayerName,  escapedTimestamp].joined(separator: ",")
            csvText += row + "\n"
        }
        
        // Save to temporary file
        let fileName = "MatchActions_\(currentMatchId ?? "Unknown").csv"
        let tempDir = FileManager.default.temporaryDirectory
        let fileURL = tempDir.appendingPathComponent(fileName)
        
        do {
            try csvText.write(to: fileURL, atomically: true, encoding: .utf8)
            return fileURL
        } catch {
            print("Error writing CSV file: \(error)")
            showErrorAlert(message: "Failed to generate CSV file.")
            return nil
        }
    }
        // MARK: - Firestore Data Fetching
        private func fetchTeamNames() {
            let db = Firestore.firestore()
            guard let matchId = currentMatchId else {
                showErrorAlert(message: "No match ID provided.")
                return
            }
            
            db.collection("match").document(matchId).getDocument { [weak self] (document, error) in
                guard let self = self else { return }
                
                if let error = error {
                    print("Error fetching team names: \(error)")
                    self.showErrorAlert(message: "Failed to fetch team names.")
                    return
                }
                
                guard let document = document, document.exists else {
                    self.showErrorAlert(message: "Match data not found.")
                    return
                }
                
                self.team1Name = document.get("team1") as? String ?? "Team 1"
                self.team2Name = document.get("team2") as? String ?? "Team 2"
                
                // Update title with team names
                DispatchQueue.main.async {
                    self.title = "\(self.team1Name ?? "Team 1") vs \(self.team2Name ?? "Team 2") Actions"
                }
                
                // Fetch actions after team names are loaded
                self.fetchActionData()
            }
        }
        
        private func fetchActionData() {
            let db = Firestore.firestore()
            
            guard let matchId = currentMatchId else {
                showErrorAlert(message: "No match ID provided.")
                return
            }
            
            let activityIndicator = UIActivityIndicatorView(style: .large)
            activityIndicator.center = view.center
            activityIndicator.startAnimating()
            view.addSubview(activityIndicator)
            
            db.collection("match")
                .document(matchId)
                .collection("actions")
                .order(by: "timestamp", descending: false)
                .getDocuments { [weak self] (snapshot, error) in
                    DispatchQueue.main.async {
                        activityIndicator.removeFromSuperview()
                    }
                    
                    guard let self = self else { return }
                    
                    if let error = error {
                        print("Error fetching actions: \(error)")
                        self.showErrorAlert(message: "Failed to fetch actions.")
                        return
                    }
                    
                    guard let documents = snapshot?.documents else {
                        self.showErrorAlert(message: "No action data found.")
                        return
                    }
                    
                    do {
                        self.actions = try documents.map { try $0.data(as: MatchAction.self) }
                        DispatchQueue.main.async {
                            self.actionTableView.reloadData()
                        }
                    } catch {
                        print("Error decoding action documents: \(error)")
                        self.showErrorAlert(message: "Failed to decode action data: \(error.localizedDescription)")
                    }
                }
        }
        
        // MARK: - TableView DataSource Methods
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return actions.count
        }
        
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "ActionCell", for: indexPath) as! ActionTableViewCell
        
        let action = actions[indexPath.row]
        
        let team1Text: String
        let team2Text: String
        
        // Use a fixed maxLength to match the header width (80 points ~ 10-12 characters)
        let maxLength = 10 // Adjust based on font size and width
        
        let playerInfo = "\(action.playerNumber)-\(action.playerName)"
        
        if action.teamName == team1Name {
            team1Text = playerInfo.padding(toLength: maxLength, withPad: " ", startingAt: 0)
            team2Text = String(repeating: " ", count: maxLength)
        } else if action.teamName == team2Name {
            team1Text = String(repeating: " ", count: maxLength)
            team2Text = playerInfo.padding(toLength: maxLength, withPad: " ", startingAt: 0)
        } else {
            team1Text = String(repeating: " ", count: maxLength)
            team2Text = String(repeating: " ", count: maxLength)
        }
        
        cell.team1.text = team1Text
        cell.quarter.text = "Q\(action.quarter)"
        cell.time.text = action.quarterTime
        cell.action.text = action.action
        cell.team2.text = team2Text
        
        // Ensure consistent alignment
        cell.team1.textAlignment = .left
        cell.quarter.textAlignment = .center
        cell.time.textAlignment = .center
        cell.action.textAlignment = .center
        cell.team2.textAlignment = .right
        
        return cell
    }
    
    

    
        // MARK: - Navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "fromActiontoMatchSummry",
               let destinationVC = segue.destination as? ScoreViewController {
                destinationVC.currentMatchId = currentMatchId
                destinationVC.team1Name = team1Name
                destinationVC.team2Name = team2Name
            }
            else if segue.identifier == "fromActiontoPlayer",
            let destinationVC = segue.destination as? PlayerStatViewController {
                destinationVC.currentMatchId = currentMatchId
                destinationVC.team1Name = team1Name
                destinationVC.team2Name = team2Name
            }
            
        }
        
        // MARK: - Show Error Alert
        private func showErrorAlert(message: String) {
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }

