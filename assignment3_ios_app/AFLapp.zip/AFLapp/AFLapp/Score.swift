//
//  Score.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 17/5/2025.
//

import Foundation
struct QuarterScores {
    var goals: Int = 0
    var behinds: Int = 0
    var kicks: Int = 0
    var handballs: Int = 0
    var marks: Int = 0
    var tackles: Int = 0
        
        /// Calculates the total points for the quarter or match (goals * 6 + behinds).
        /// - Returns: The total points as an integer.
        func totalPoints() -> Int {
            return goals * 6 + behinds
        }
        
        /// Formats the score as a string in the AFL format: "goals.behinds (totalPoints)".
        /// - Returns: A string like "2.3 (15)" for 2 goals, 3 behinds.
        func formattedScore() -> String {
            return "\(goals).\(behinds) (\(totalPoints()))"
        }
        
        /// Calculates the total disposals (kicks + handballs).
        func disposals() -> Int {
            return kicks + handballs
        }
        
        /// Formats the disposals as a string in the format "(kicks + handballs) Disposal".
        /// - Returns: A string like "(10 + 5) Disposal".
        func formattedDisposals() -> String {
            return "(\(kicks) + \(handballs)(\(disposals()))"
        }
        
        /// Returns the number of marks as a string.
        /// - Returns: A string like "5" for 5 marks.
        func formattedMarks() -> String {
            return "\(marks)"
        }
        
        /// Returns the number of tackles as a string.
        /// - Returns: A string like "4" for 4 tackles.
        func formattedTackles() -> String {
            return "\(tackles)"
        }
    }
