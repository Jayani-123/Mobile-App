//
//  Match.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 6/5/2025.
//

import Firebase
import FirebaseFirestore


public struct Match : Codable
{
    @DocumentID var documentID:String?
    var name:String
    var dateTime:String
    var venue:String
    var team1:String
    var team2:String
    var team1players: [String]?  
    var team2players: [String]?
    var timestamp: String
    var isFinished:Bool = false
}
 
