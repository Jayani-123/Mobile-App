//
//  CreateViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 2/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class CreateViewController: UIViewController {
    
    
    @IBOutlet weak var datePicker: UIDatePicker!
    
    @IBOutlet weak var matchName: UITextField!
    
    @IBOutlet weak var venu: UITextField!
    
    @IBOutlet weak var team1name: UITextField!
    
    @IBOutlet weak var team2name: UITextField!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        navigationController?.navigationBar.tintColor = .white
        datePicker.datePickerMode =  .dateAndTime
  
    }
    
    
    @IBAction func dateChanged(_ sender: UIDatePicker) {
        let formatter = DateFormatter()
        formatter.dateStyle = .medium
        formatter.timeStyle = .short
        
    }
    
    @IBAction func saveMatchDetails(_ sender: UIButton) {
        // Get data from the text fields
        guard let matchNameText = matchName.text, !matchNameText.isEmpty,
              let venueText = venu.text, !venueText.isEmpty,
              let team1Text = team1name.text, !team1Text.isEmpty,
              let team2Text = team2name.text, !team2Text.isEmpty 
        
        else {
            print("Please fill all the fields")
            return
        }
        // Get the selected date from the date picker and format it to a string
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd HH:mm:ss"
        let selectedDate = formatter.string(from: datePicker.date)
        // Get the current date and time for timestamp
        let currentDateTime = formatter.string(from: Date())
                                               
        let match = Match(name: matchNameText, dateTime: selectedDate, venue: venueText, team1: team1Text, team2: team2Text, timestamp: currentDateTime,isFinished: false)
        
        let db = Firestore.firestore()
        print("\nINITIALIZED FIRESTORE APP \(db.app.name)\n")
        let matchCollection = db.collection("match")
        
        let newDocRef = matchCollection.document() // Create a new document reference
        let matchWithID = match  // Optional: update your match object if needed

        do {
            try newDocRef.setData(from: matchWithID) { err in
                if let err = err {
                    print("Error adding document: \(err)")
                } else {
                    self.performSegue(withIdentifier: "toPlayer", sender: newDocRef.documentID)
                    print("Successfully created match")
                }
            }
        } catch let error {
            print("Error writing to Firestore: \(error)")
        }

       
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toPlayer",
           let destinationVC = segue.destination as? PlayerViewController,
           let matchID = sender as? String {
            destinationVC.matchDocumentID = matchID
        }
    }

}



