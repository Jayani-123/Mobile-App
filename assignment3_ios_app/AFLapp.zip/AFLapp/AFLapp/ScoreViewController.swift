//
//  ScoreViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 17/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class ScoreViewController: UIViewController {
    // MARK: - IBOutlets
    @IBOutlet weak var winnerLabel: UILabel!
    @IBOutlet weak var team1NameLabel: UILabel!
    @IBOutlet weak var team1Q1score: UILabel!
    @IBOutlet weak var team1Q2score: UILabel!
    @IBOutlet weak var team1Q3score: UILabel!
    @IBOutlet weak var team1Q4score: UILabel!
    @IBOutlet weak var team1TotalLabel: UILabel!
    
    
    @IBOutlet weak var team2NameLabel: UILabel!
    @IBOutlet weak var team2Q1score: UILabel!
    @IBOutlet weak var team2Q2score: UILabel!
    @IBOutlet weak var team2Q3score: UILabel!
    @IBOutlet weak var team2Q4score: UILabel!
    @IBOutlet weak var team2TotalLabel: UILabel!
    
    @IBOutlet weak var team1TackleLabel: UILabel!
    @IBOutlet weak var team1MarksLabel: UILabel!
    @IBOutlet weak var team2TackleLabel: UILabel!
    @IBOutlet weak var team2MarksLabel: UILabel!
    
    @IBOutlet weak var team1disposallabel: UILabel!
    
    @IBOutlet weak var team2disposallabel: UILabel!
    
    // MARK: - Properties
    var team1Scores = [String: QuarterScores]()
    var team2Scores = [String: QuarterScores]()
    // property to track match status
    private var matchIsFinished: Bool = false
    var team1TotalStats = QuarterScores()
    var team2TotalStats = QuarterScores()
    
    var leadingText = "Loading..."
    
    let db = Firestore.firestore()
    var currentMatchId: String?
    var team1Name: String?
    var team2Name: String?
    
    private var team1DataLoaded = false
    private var team2DataLoaded = false
    
    // MARK: - Lifecycle
    override func viewDidLoad() {
        super.viewDidLoad()
        // Set default UI state
        setupDefaultUI()
        // Load data only if properties are set
        if let team1 = team1Name, let team2 = team2Name, let matchId = currentMatchId {
            loadMatchStatus(matchId: matchId)
            loadTeamStatistics(teamName: team1, isTeam1: true)
            loadTeamStatistics(teamName: team2, isTeam1: false)
        } else {
            winnerLabel.text = "Error: Match data not set"
        }
    }
    
    // MARK: - Load Match Status
        private func loadMatchStatus(matchId: String) {
            let db = Firestore.firestore()
            db.collection("match").document(matchId).getDocument { [weak self] (document, error) in
                guard let self = self, let document = document, document.exists, error == nil else {
                    print("Error fetching match status: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                let isFinished = document.get("isFinished") as? Bool ?? false
                DispatchQueue.main.async {
                    // Store the match status for use in updateLeadingText
                    self.matchIsFinished = isFinished
                    // Update UI if both team data are loaded
                    if self.team1DataLoaded && self.team2DataLoaded {
                        self.updateLeadingText()
                        self.winnerLabel.text = self.leadingText
                    }
                }
            }
        }
    
    // MARK: - Firebase Data Load
    func loadTeamStatistics(teamName: String, isTeam1: Bool) {
        guard !teamName.isEmpty, currentMatchId != nil else {
            print("Error: Invalid team name or match ID")
            return
        }
        
        let types = ["Goal", "Behind", "Kick", "Handball", "Mark", "Tackle"]
        var results = [String: [QueryDocumentSnapshot]]()
        let group = DispatchGroup()
        
        for type in types {
            group.enter()
            db.collection("match").document(currentMatchId!).collection("actions")
                .whereField("teamName", isEqualTo: teamName)
                .whereField("action", isEqualTo: type)
                .getDocuments { (snapshot, error) in
                    if let error = error {
                        print("Error fetching \(type) for \(teamName): \(error)")
                    } else if let snapshot = snapshot {
                        results[type] = snapshot.documents
                    }
                    group.leave()
                }
        }
        
        group.notify(queue: .main) {
            let goals = results["Goal"] ?? []
            let behinds = results["Behind"] ?? []
            let kicks = results["Kick"] ?? []
            let handballs = results["Handball"] ?? []
            let marks = results["Mark"] ?? []
            let tackles = results["Tackle"] ?? []
            
            let scores = self.calculateQuarterlyScores(goals: goals, behinds: behinds)
            var total = self.calculateTotalScores(goals: goals, behinds: behinds)
            total.kicks = kicks.count
            total.handballs = handballs.count
            total.marks = marks.count
            total.tackles = tackles.count
            
            if isTeam1 {
                self.team1Scores = scores
                self.team1TotalStats = total
                self.team1DataLoaded = true
            } else {
                self.team2Scores = scores
                self.team2TotalStats = total
                self.team2DataLoaded = true
            }
            
            self.updateLeadingText()
            
            if self.team1DataLoaded && self.team2DataLoaded {
                self.updateTeam1UI()
                self.updateTeam2UI()
                self.winnerLabel.text = self.leadingText
            }
        }
    }
    
    // MARK: - Score Calculations
    private func calculateQuarterlyScores(goals: [QueryDocumentSnapshot], behinds: [QueryDocumentSnapshot]) -> [String: QuarterScores] {
        let quarters = [1, 2, 3, 4] // Corrected array of quarter numbers
        var result = [String: QuarterScores]()
        
        for quarter in quarters {
            let gCount = goals.filter { $0.get("quarter") as? Int == quarter }.count
            let bCount = behinds.filter { $0.get("quarter") as? Int == quarter }.count
            result["Quarter \(quarter)"] = QuarterScores(goals: gCount, behinds: bCount)
        }
        return result
    }
    
    private func calculateTotalScores(goals: [QueryDocumentSnapshot], behinds: [QueryDocumentSnapshot]) -> QuarterScores {
        return QuarterScores(goals: goals.count, behinds: behinds.count)
    }
    


        // MARK: - Update Leading Text
        private func updateLeadingText() {
            let team1Points = team1TotalStats.totalPoints()
            let team2Points = team2TotalStats.totalPoints()
            
            if matchIsFinished {
                if team1Points > team2Points {
                    leadingText = "\(team1Name ?? "Team 1") wins!"
                } else if team2Points > team1Points {
                    leadingText = "\(team2Name ?? "Team 2") wins!"
                } else {
                    leadingText = "Match is a draw"
                }
            } else {
                if team1Points > team2Points {
                    leadingText = "\(team1Name ?? "Team 1") is leading"
                } else if team2Points > team1Points {
                    leadingText = "\(team2Name ?? "Team 2") is leading"
                } else {
                    leadingText = "Scores are tied"
                }
            }
        }
    
    // MARK: - UI Update
    private func setupDefaultUI() {
        team1NameLabel.text = team1Name ?? "Team 1"
        team2NameLabel.text = team2Name ?? "Team 2"
        team1Q1score.text = "0.0 (0)"
        team1Q2score.text = "0.0 (0)"
        team1Q3score.text = "0.0 (0)"
        team1Q4score.text = "0.0 (0)"
        team1TotalLabel.text = "0 pts"
        team2Q1score.text = "0.0 (0)"
        team2Q2score.text = "0.0 (0)"
        team2Q3score.text = "0.0 (0)"
        team2Q4score.text = "0.0 (0)"
        team2TotalLabel.text = "0"
        team1disposallabel.text = "(0 + 0) Disposal"
        team2disposallabel.text = "(0 + 0) Disposal"
        winnerLabel.text = "Loading..."
    }
    
    private func updateTeam1UI() {
        team1NameLabel.text = team1Name ?? "Team 1"
        team1Q1score.text = formatQuarterScore(for: "Quarter 1", in: team1Scores)
        team1Q2score.text = formatQuarterScore(for: "Quarter 2", in: team1Scores)
        team1Q3score.text = formatQuarterScore(for: "Quarter 3", in: team1Scores)
        team1Q4score.text = formatQuarterScore(for: "Quarter 4", in: team1Scores)
        team1TotalLabel.text = "\(team1TotalStats.totalPoints())"
        team1TackleLabel.text = "\(team1TotalStats.tackles)"
        team1MarksLabel.text = "\(team1TotalStats.marks)"
        team1disposallabel.text = "(\(team1TotalStats.kicks)+\(team1TotalStats.handballs)) \(team1TotalStats.disposals())"
        
    }
    
    private func updateTeam2UI() {
        team2NameLabel.text = team2Name ?? "Team 2"
        team2Q1score.text = formatQuarterScore(for: "Quarter 1", in: team2Scores)
        team2Q2score.text = formatQuarterScore(for: "Quarter 2", in: team2Scores)
        team2Q3score.text = formatQuarterScore(for: "Quarter 3", in: team2Scores)
        team2Q4score.text = formatQuarterScore(for: "Quarter 4", in: team2Scores)
        team2TotalLabel.text = "\(team2TotalStats.totalPoints())"
        team2TackleLabel.text = "\(team2TotalStats.tackles)"
        team2MarksLabel.text = "\(team2TotalStats.marks)"
        team2disposallabel.text = "(\(team2TotalStats.kicks)+\(team2TotalStats.handballs)) \(team2TotalStats.disposals())"
        
    }
    
    private func formatQuarterScore(for quarter: String, in scores: [String: QuarterScores]) -> String {
        if let score = scores[quarter] {
            return "\(score.goals).\(score.behinds) (\(score.totalPoints()))"
        }
        return "0.0 (0)"
    }
    
    // MARK: - Navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toWormChart",
           let destinationVC = segue.destination as? WormViewController {
            destinationVC.currentMatchId = currentMatchId
            destinationVC.team1Name = team1Name
            destinationVC.team2Name = team2Name
        }   else if segue.identifier == "fromScoretoPlayer",
      let destinationVC = segue.destination as? PlayerStatViewController {
            destinationVC.currentMatchId = currentMatchId
            destinationVC.team1Name = team1Name
            destinationVC.team2Name = team2Name
        }
        
        
        
    }
}
