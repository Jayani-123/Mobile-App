//
//  MatchAction.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 14/5/2025.
//


import Firebase
import FirebaseFirestore



struct MatchAction: Codable {
    let action: String
    let playerId: String   
    let playerName: String
    let playerNumber: String
    let teamName: String
    let timestamp: Date
    let quarter: Int
    let quarterTime: String
}
