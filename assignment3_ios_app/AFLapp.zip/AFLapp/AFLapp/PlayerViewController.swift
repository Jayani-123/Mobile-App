//
//  PlayerViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 7/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class PlayerViewController: UIViewController,UITableViewDelegate, UITableViewDataSource,UISearchBarDelegate
{
    
    var matchDocumentID: String?
        var playerTeam1 = [Player]()
        var playerTeam2 = [Player]()
        var filteredPlayerTeam1: [Player] = []
        var filteredPlayerTeam2: [Player] = []
        var teamNames: [String] = ["Team1", "Team2"]
        var searchController: UISearchController!
        
   
    
    var isSearching: Bool {
            return !(searchBar.text?.isEmpty ?? true)
        }
    
    @IBOutlet weak var searchBar: UISearchBar!
    
    @IBOutlet weak var tableViewTeam1: UITableView!
    @IBOutlet weak var tableViewTeam2: UITableView!
    
    @IBOutlet weak var deleteButton: UIButton!
    
    override func viewDidLoad() {
            super.viewDidLoad()
            print("Match ID received: \(matchDocumentID ?? "None")")
            
            // Set up table view delegates and data sources
            tableViewTeam1.delegate = self
            tableViewTeam1.dataSource = self
            tableViewTeam2.delegate = self
            tableViewTeam2.dataSource = self
            
            // Ensure editing is off initially
            tableViewTeam1.setEditing(false, animated: false)
            tableViewTeam2.setEditing(false, animated: false)
            deleteButton.setTitle("Delete", for: .normal)
            
            
        // Set up search bar
                searchBar.delegate = self
                searchBar.placeholder = "Search Players by Name"
       
        
            loadTeamNames()
            loadPlayers()
        }
        
        override func viewDidAppear(_ animated: Bool) {
            super.viewDidAppear(animated)
            loadTeamNames()
            loadPlayers()
        }
    // MARK: - Add Button Action
    @IBAction func addButtonTapped(_ sender: UIButton) {
        performSegue(withIdentifier: "toPlayerDetails", sender: matchDocumentID)
            }
            
 
    // MARK: - Prepare for Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toPlayerDetails",
           let destinationVC = segue.destination as? PlayerDetailsViewController {
            destinationVC.matchDocumentID = matchDocumentID
            destinationVC.teamNames = teamNames
            
            if let (player, team) = sender as? (Player, String) {
                destinationVC.playerToEdit = player
                destinationVC.playerTeam = team
            }
        } else if segue.identifier == "toRecordView" {
            if let destinationVC = segue.destination as? RecordViewController {
                // Validate player count before proceeding
                if !validatePlayerCount() {
                    showMinimumPlayerAlert()
                    return
                }
                destinationVC.currentMatchId = matchDocumentID
            }
        }
    }

    // MARK: - Validate Player Count
    func validatePlayerCount() -> Bool {
        return playerTeam1.count >= 2 && playerTeam2.count >= 2
    }

    // MARK: - Show Alert for Insufficient Players
    func showMinimumPlayerAlert() {
        let alert = UIAlertController(
            title: "Insufficient Players",
            message: "Each team must have at least two players to record a match. Please add more players.",
            preferredStyle: .alert
        )
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true, completion: nil)
    }
    
        // MARK: - Load Team Names
        func loadTeamNames() {
            guard let matchID = matchDocumentID else { return }
            let db = Firestore.firestore()
            db.collection("match").document(matchID).getDocument { (document, error) in
                if let document = document, document.exists {
                    let team1Name = document.get("team1") as? String ?? "Team1"
                    let team2Name = document.get("team2") as? String ?? "Team2"
                    self.teamNames = [team1Name, team2Name]
                    self.tableViewTeam1.reloadData()
                    self.tableViewTeam2.reloadData()
                }
            }
        }
        
        func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
            return tableView == tableViewTeam1 ? teamNames[0] : teamNames[1]
        }
        
        // MARK: - Load Players from Firestore
        func loadPlayers() {
            guard let matchID = matchDocumentID else {
                print("No match ID provided")
                return
            }
            
            let db = Firestore.firestore()
            let matchRef = db.collection("match").document(matchID)
            
            // Load Team 1 players
            matchRef.collection("team1players").getDocuments { (snapshot, error) in
                if let error = error {
                    print("Error getting team1players: \(error)")
                    return
                }
                
                self.playerTeam1.removeAll()
                for document in snapshot!.documents {
                    do {
                        var player = try document.data(as: Player.self)
                        player.documentID = document.documentID
                        self.playerTeam1.append(player)
                    } catch {
                        print("Error decoding player: \(error)")
                    }
                }
                if !self.isSearching {
                    self.filteredPlayerTeam1 = self.playerTeam1
                }
                self.tableViewTeam1.reloadData()
            }
            
            // Load Team 2 players
            matchRef.collection("team2players").getDocuments { (snapshot, error) in
                if let error = error {
                    print("Error getting team2players: \(error)")
                    return
                }
                
                self.playerTeam2.removeAll()
                for document in snapshot!.documents {
                    do {
                        var player = try document.data(as: Player.self)
                        player.documentID = document.documentID
                        self.playerTeam2.append(player)
                    } catch {
                        print("Error decoding player: \(error)")
                    }
                }
                if !self.isSearching {
                    self.filteredPlayerTeam2 = self.playerTeam2
                }
                self.tableViewTeam2.reloadData()
            }
        }
        
        // MARK: - UITableViewDataSource
        func numberOfSections(in tableView: UITableView) -> Int {
            return 1
        }
        
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            let count = tableView == tableViewTeam1 ? filteredPlayerTeam1.count : filteredPlayerTeam2.count
            if count == 0, isSearching {
                let label = UILabel(frame: tableView.bounds)
                label.text = "No players found"
                label.textAlignment = .center
                label.textColor = .gray
                tableView.backgroundView = label
            } else {
                tableView.backgroundView = nil
            }
            return count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "playercell", for: indexPath)
            let player = tableView == tableViewTeam1 ? filteredPlayerTeam1[indexPath.row] : filteredPlayerTeam2[indexPath.row]
            
            if let playerCell = cell as? PlayerTableViewCell {
                if let nameLabel = playerCell.name {
                    nameLabel.text = player.number + " - " + player.name
                } else {
                    print("Warning: name label is not connected in PlayerTableViewCell")
                }
            } else {
                print("Warning: Cell is not a PlayerTableViewCell")
            }
            
            return cell
        }
        
        // MARK: - UITableViewDelegate
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            let selectedPlayer = tableView == tableViewTeam1 ? filteredPlayerTeam1[indexPath.row] : filteredPlayerTeam2[indexPath.row]
            let team = tableView == tableViewTeam1 ? "team1players" : "team2players"
            performSegue(withIdentifier: "toPlayerDetails", sender: (selectedPlayer, team))
        }
        
        func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
            return true
        }
        
        func tableView(_ tableView: UITableView, editingStyleForRowAt indexPath: IndexPath) -> UITableViewCell.EditingStyle {
            return tableView.isEditing ? .delete : .none
        }
        
        func tableView(_ tableView: UITableView, trailingSwipeActionsConfigurationForRowAt indexPath: IndexPath) -> UISwipeActionsConfiguration? {
            // Only show swipe actions when not in editing mode
            guard !tableView.isEditing else { return nil }
            
            let editAction = UIContextualAction(style: .normal, title: "Edit") { [weak self] (action, view, completion) in
                guard let self = self else { return }
                let selectedPlayer = tableView == self.tableViewTeam1 ? self.filteredPlayerTeam1[indexPath.row] : self.filteredPlayerTeam2[indexPath.row]
                let team = tableView == self.tableViewTeam1 ? "team1players" : "team2players"
                self.performSegue(withIdentifier: "toPlayerDetails", sender: (selectedPlayer, team))
                completion(true)
            }
            editAction.backgroundColor = .systemBlue
            
            let configuration = UISwipeActionsConfiguration(actions: [editAction])
            configuration.performsFirstActionWithFullSwipe = true
            return configuration
        }
        
        func tableView(_ tableView: UITableView, commit editingStyle: UITableViewCell.EditingStyle, forRowAt indexPath: IndexPath) {
            guard editingStyle == .delete, let matchID = matchDocumentID else { return }
            
            let db = Firestore.firestore()
            let matchRef = db.collection("match").document(matchID)
            
            let player = tableView == tableViewTeam1 ? filteredPlayerTeam1[indexPath.row] : filteredPlayerTeam2[indexPath.row]
            let collection = tableView == tableViewTeam1 ? "team1players" : "team2players"
            
            if let docID = player.documentID {
                matchRef.collection(collection).document(docID).delete { error in
                    if let error = error {
                        print("Error deleting player: \(error)")
                    } else {
                        // Remove from original array
                        if let index = self.playerTeam1.firstIndex(where: { $0.documentID == docID }) {
                            self.playerTeam1.remove(at: index)
                        } else if let index = self.playerTeam2.firstIndex(where: { $0.documentID == docID }) {
                            self.playerTeam2.remove(at: index)
                        }
                        // Remove from filtered array
                        if tableView == self.tableViewTeam1 {
                            self.filteredPlayerTeam1.remove(at: indexPath.row)
                        } else {
                            self.filteredPlayerTeam2.remove(at: indexPath.row)
                        }
                        tableView.deleteRows(at: [indexPath], with: .fade)
                        // Exit editing mode
                        self.tableViewTeam1.setEditing(false, animated: true)
                        self.tableViewTeam2.setEditing(false, animated: true)
                        self.deleteButton.setTitle("Delete", for: .normal)
                        self.deleteButton.tintColor = .systemBlue
                        // Reset search
                        self.searchBar.text = ""
                        self.searchBar.resignFirstResponder()
                    }
                }
            } else {
                print("Error: Player documentID is nil")
            }
        }
       @IBAction func deletePressed(_ sender: Any) {
           let isEditing = tableViewTeam1.isEditing || tableViewTeam2.isEditing
                   tableViewTeam1.setEditing(!isEditing, animated: true)
                   tableViewTeam2.setEditing(!isEditing, animated: true)
                   
                   if isEditing {
                       deleteButton.setTitle("Delete", for: .normal)
                       deleteButton.tintColor = .systemBlue
                       // Reset search when exiting editing mode
                       searchBar.text = ""
                       searchBar.resignFirstResponder()
                   } else {
                       deleteButton.setTitle("Done", for: .normal)
                       deleteButton.tintColor = .systemRed
                   }
               }
               
               // MARK: - UISearchBarDelegate
               func searchBar(_ searchBar: UISearchBar, textDidChange searchText: String) {
                   if searchText.isEmpty {
                       filteredPlayerTeam1 = playerTeam1
                       filteredPlayerTeam2 = playerTeam2
                   } else {
                       filteredPlayerTeam1 = playerTeam1.filter { $0.name.lowercased().contains(searchText.lowercased()) }
                       filteredPlayerTeam2 = playerTeam2.filter { $0.name.lowercased().contains(searchText.lowercased()) }
                   }
                   tableViewTeam1.reloadData()
                   tableViewTeam2.reloadData()
               }
               
               func searchBarCancelButtonClicked(_ searchBar: UISearchBar) {
                   searchBar.text = ""
                   filteredPlayerTeam1 = playerTeam1
                   filteredPlayerTeam2 = playerTeam2
                   searchBar.resignFirstResponder()
                   tableViewTeam1.reloadData()
                   tableViewTeam2.reloadData()
               }
    


    
        }
