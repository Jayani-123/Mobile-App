//
//  HistoryViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 19/5/2025.
//
import UIKit
import Firebase
import FirebaseFirestore

class HistoryViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {


        // Outlets
        @IBOutlet weak var tableView: UITableView!
        
        // Firestore instance
    private let db = Firestore.firestore()
        
        // Array to store match data
        private var matches: [[String: Any]] = []
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Safely set up table view
            guard let tableView = tableView else {
                print("tableView outlet is not connected")
                showAlert(message: "Table view not configured.")
                return
            }
            
            tableView.dataSource = self
            tableView.delegate = self
            tableView.register(UITableViewCell.self, forCellReuseIdentifier: "MatchCell")
            
            // Set navigation title
            title = "Match History"
            
            // Fetch matches
            fetchMatches()
        }
        
        // MARK: - Fetch Matches from Firestore
        func fetchMatches() {
            db.collection("match").getDocuments { (snapshot, error) in
                if let error = error {
                    print("Error fetching matches: \(error.localizedDescription)")
                    self.showAlert(message: "Failed to load matches.")
                    return
                }
                
                guard let snapshot = snapshot else {
                    print("No matches found")
                    self.showAlert(message: "No matches available.")
                    return
                }
                
                // Store match data
                self.matches = snapshot.documents.map { doc in
                    var matchData = doc.data()
                    print("Match \(doc.documentID): \(matchData)")
                    matchData["matchID"] = doc.documentID
                    return matchData
                }
                
                print("Fetched \(self.matches.count) matches")
                self.tableView?.reloadData()
            }
        }
        
        // MARK: - UITableViewDataSource
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return matches.count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "MatchCell", for: indexPath)
            
            let match = matches[indexPath.row]
            let matchID = match["matchID"] as? String ?? "Unknown Match"
            let team1 = match["team1"] as? String ?? "Team 1"
            let team2 = match["team2"] as? String ?? "Team 2"
            let date = match["dateTime"] as? String ?? "Unknown Date"
            
            cell.textLabel?.text = "\(team1) vs \(team2) \(date)"
            cell.detailTextLabel?.text = "Match ID: \(matchID)"
            
            return cell
        }
        
        // MARK: - UITableViewDelegate
        func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
            tableView.deselectRow(at: indexPath, animated: true)
            
            // Trigger segue
            performSegue(withIdentifier: "ShowActionViewController", sender: indexPath)
        }
        
        // MARK: - Navigation
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            if segue.identifier == "ShowActionViewController",
               let actionVC = segue.destination as? ActionViewController,
               let indexPath = sender as? IndexPath {
                let match = matches[indexPath.row]
                guard let matchID = match["matchID"] as? String else {
                    showAlert(message: "Invalid match ID.")
                    return
                }
                
                let team1Name = match["team1"] as? String ?? "Team 1"
                let team2Name = match["team2"] as? String ?? "Team 2"
                
                actionVC.currentMatchId = matchID
                actionVC.team1Name = team1Name
                actionVC.team2Name = team2Name
            }
        }
        
        // MARK: - Show Alert
        func showAlert(message: String) {
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
