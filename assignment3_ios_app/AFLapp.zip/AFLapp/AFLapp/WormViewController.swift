//
//  WormViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 20/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class WormViewController: UIViewController {
    
    private let db = Firestore.firestore()
    private var actions: [MatchAction] = []
    
    var currentMatchId: String?
    var team1Name: String?
    var team2Name: String?
    
    private let wormGraphView = WormGraphView()
    
    override func viewDidLoad() {
        super.viewDidLoad()

        
        // Set up worm graph view
        wormGraphView.translatesAutoresizingMaskIntoConstraints = false
        wormGraphView.backgroundColor = UIColor(white:1, alpha:1)
        view.addSubview(wormGraphView)
        
        NSLayoutConstraint.activate([
            wormGraphView.leadingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.leadingAnchor, constant: 16),
            wormGraphView.trailingAnchor.constraint(equalTo: view.safeAreaLayoutGuide.trailingAnchor, constant: -16),
            wormGraphView.topAnchor.constraint(equalTo: view.safeAreaLayoutGuide.topAnchor, constant: 16),
            wormGraphView.bottomAnchor.constraint(equalTo: view.safeAreaLayoutGuide.bottomAnchor, constant: -16)
        ])
        
        // Fetch actions
        fetchActions()
    }
    
    private func fetchActions() {
        guard let matchId = currentMatchId else {
            showAlert(message: "No match ID provided.")
            return
        }
        
        let activityIndicator = UIActivityIndicatorView(style: .large)
        activityIndicator.center = view.center
        activityIndicator.startAnimating()
        view.addSubview(activityIndicator)
        
        db.collection("match")
            .document(matchId)
            .collection("actions")
            .order(by: "timestamp", descending: false)
            .getDocuments { [weak self] (snapshot, error) in
                DispatchQueue.main.async {
                    activityIndicator.removeFromSuperview()
                }
                
                guard let self = self else { return }
                
                if let error = error {
                    print("Error fetching actions: \(error)")
                    self.showAlert(message: "Failed to fetch actions.")
                    return
                }
                
                guard let documents = snapshot?.documents else {
                    self.showAlert(message: "No action data found.")
                    return
                }
                
                do {
                    self.actions = try documents.map { doc in
                        let action = try doc.data(as: MatchAction.self)
                        return action
                    }
                    self.calculateScores()
                } catch {
                    print("Error decoding action documents: \(error)")
                    self.showAlert(message: "Failed to decode action data.")
                }
            }
    }
    
    private func calculateScores() {
        var team1Scores: [(time: TimeInterval, score: Int)] = [(0, 0)]
        var team2Scores: [(time: TimeInterval, score: Int)] = [(0, 0)]
        var quarterTimes: [TimeInterval] = []
        
        var team1Total = 0
        var team2Total = 0
        var currentQuarter = 1
        
        let startTime = actions.first?.timestamp.timeIntervalSince1970 ?? 0
        
        for action in actions {
            let teamName = action.teamName
            let time = action.timestamp.timeIntervalSince1970 - startTime
            
            if action.quarter > currentQuarter {
                quarterTimes.append(time)
                currentQuarter = action.quarter
            }
            
            var points = 0
            if action.action.lowercased() == "goal" {
                points = 6
            } else if action.action.lowercased() == "behind" {
                points = 1
            }
            
            if teamName == team1Name {
                team1Total += points
                team1Scores.append((time, team1Total))
                if let lastTeam2 = team2Scores.last {
                    team2Scores.append((time, lastTeam2.score))
                }
            } else if teamName == team2Name {
                team2Total += points
                team2Scores.append((time, team2Total))
                if let lastTeam1 = team1Scores.last {
                    team1Scores.append((time, lastTeam1.score))
                }
            }
        }
        
        if let lastTime = actions.last?.timestamp.timeIntervalSince1970 {
            let finalTime = lastTime - startTime
            while quarterTimes.count < 3 {
                quarterTimes.append(finalTime)
            }
        }
        
        wormGraphView.team1Scores = team1Scores
        wormGraphView.team2Scores = team2Scores
        wormGraphView.team1Name = team1Name ?? "Team 1"
        wormGraphView.team2Name = team2Name ?? "Team 2"
        wormGraphView.quarters = quarterTimes
        
        if team1Scores.count <= 1 && team2Scores.count <= 1 {
            showAlert(message: "No scoring actions found for this match.")
        }
        
        wormGraphView.setNeedsDisplay()
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default))
        present(alert, animated: true)
    }
}

