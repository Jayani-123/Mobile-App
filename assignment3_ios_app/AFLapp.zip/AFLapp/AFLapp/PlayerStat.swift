//
//  PlayerStat.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 18/5/2025.
//

import Foundation
struct PlayerStats {

        let number: String
        let name: String
        var goals: Int
        var behinds: Int
        var kicks: Int
        var handballs: Int
        var marks: Int
        var tackles: Int
}
