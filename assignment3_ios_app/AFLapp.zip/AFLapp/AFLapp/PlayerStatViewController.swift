//
//  PlayerStatViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 17/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class PlayerStatViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    var currentMatchId: String?
    var team1Name: String?
    var team2Name: String?
    
    @IBOutlet weak var team1View: UITableView!
    
    @IBOutlet weak var team2View: UITableView!
    
    @IBOutlet weak var team1NameLabel: UILabel!
    
    
    @IBOutlet weak var team2NameLabel: UILabel!
    
    private var team1PlayerStats: [PlayerStats] = []
        private var team2PlayerStats: [PlayerStats] = []
        
        private let db = Firestore.firestore()
        
        override func viewDidLoad() {
            super.viewDidLoad()
            
            // Set team name labels with proper fallbacks
            team1NameLabel.text = team1Name ?? "Team 1"
            team2NameLabel.text = team2Name ?? "Team 2"
            
            print("currentMatchId: \(String(describing: currentMatchId))")
            print("team1Name: \(String(describing: team1Name))")
            print("team2Name: \(String(describing: team2Name))")
            
            team1View.delegate = self
            team1View.dataSource = self
            team2View.delegate = self
            team2View.dataSource = self
            

            
            if let team1 = team1Name {
                loadTeamPlayersStat(teamName: team1, isTeam1: true)
            }
            if let team2 = team2Name {
                loadTeamPlayersStat(teamName: team2, isTeam1: false)
            }
        }
        
        // MARK: - Firebase Data Load
        func loadTeamPlayersStat(teamName: String, isTeam1: Bool) {
            guard !teamName.isEmpty, let matchId = currentMatchId else {
                showAlert(message: "Invalid team name or match ID.")
                return
            }
            
            let types = ["Goal", "Behind", "Kick", "Handball", "Mark", "Tackle"]
            var results: [String: [QueryDocumentSnapshot]] = [:]
            let group = DispatchGroup()
            
            for type in types {
                group.enter()
                db.collection("match").document(matchId).collection("actions")
                    .whereField("teamName", isEqualTo: teamName)
                    .whereField("action", isEqualTo: type)
                    .getDocuments { (snapshot, error) in
                        if let error = error {
                            print("Error fetching \(type) for \(teamName): \(error)")
                            self.showAlert(message: "Failed to load \(type) stats for \(teamName).")
                        } else if let snapshot = snapshot {
                            print("Fetched \(snapshot.documents.count) \(type) actions for \(teamName)")
                            results[type] = snapshot.documents
                        }
                        group.leave()
                    }
            }
            
            group.notify(queue: .main) {
                var playerStatsDict: [String: PlayerStats] = [:]
                
                // Process each action type
                for type in types {
                    let documents = results[type] ?? []
                    for doc in documents {
                        guard let number = doc.data()["playerNumber"] as? String else {
                            print("Missing number in document: \(doc.data())")
                            continue
                        }
                        guard let name = doc.data()["playerName"] as? String else {
                            print("Missing number in document: \(doc.data())")
                            continue
                        }
                        if playerStatsDict[number] == nil {
                            playerStatsDict[number] = PlayerStats(
                                number: number,
                                name: name,
                                goals: 0,
                                behinds: 0,
                                kicks: 0,
                                handballs: 0,
                                marks: 0,
                                tackles: 0
                            )
                        }
                        
                        var stats = playerStatsDict[number]!
                        switch type {
                        case "Goal":
                            stats.goals += 1
                        case "Behind":
                            stats.behinds += 1
                        case "Kick":
                            stats.kicks += 1
                        case "Handball":
                            stats.handballs += 1
                        case "Mark":
                            stats.marks += 1
                        case "Tackle":
                            stats.tackles += 1
                        default:
                            break
                        }
                        playerStatsDict[number] = stats
                    }
                }
                
                let playerStatsArray = playerStatsDict.values.sorted { $0.number < $1.number }
                print("Player stats for \(teamName): \(playerStatsArray)")
                
                if isTeam1 {
                    self.team1PlayerStats = playerStatsArray
                } else {
                    self.team2PlayerStats = playerStatsArray
                }
                
                if playerStatsArray.isEmpty {
                    self.showAlert(message: "No stats available for \(teamName).")
                }
                
                self.fetchPlayerNames(for: teamName, matchId: matchId, isTeam1: isTeam1, playerStats: playerStatsArray)
            }
        }
        
        // MARK: - Fetch Player Names
        private func fetchPlayerNames(for teamName: String, matchId: String, isTeam1: Bool, playerStats: [PlayerStats]) {
            let subcollection = teamName == team1Name ? "team1players" : "team2players"
            db.collection("match").document(matchId).collection(subcollection)
                .getDocuments { (snapshot, error) in
                    if let error = error {
                        print("Error fetching player names for \(teamName): \(error)")
                        self.showAlert(message: "Failed to load player names for \(teamName).")
                        return
                    }
                    
                    var updatedStats = playerStats
                    if let documents = snapshot?.documents {
                        print("Fetched \(documents.count) players for \(teamName)")
                        for (index, stats) in updatedStats.enumerated() {
                            if let playerDoc = documents.first(where: { $0.data()["playerNumber"] as? String == stats.number }),
                               let name = playerDoc.data()["playerName"] as? String {
                                updatedStats[index] = PlayerStats(
                                    number: stats.number,
                                    name: name,
                                    goals: stats.goals,
                                    behinds: stats.behinds,
                                    kicks: stats.kicks,
                                    handballs: stats.handballs,
                                    marks: stats.marks,
                                    tackles: stats.tackles
                                )
                            }
                        }
                    }
                    
                    if isTeam1 {
                        self.team1PlayerStats = updatedStats
                        self.team1View.reloadData()
                    } else {
                        self.team2PlayerStats = updatedStats
                        self.team2View.reloadData()
                    }
                }
        }
        
        // MARK: - UITableViewDataSource
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            let count = tableView == team1View ? team1PlayerStats.count : team2PlayerStats.count
            print("Table view \(tableView == team1View ? "Team1" : "Team2") rows: \(count)")
            return count
        }
        
        func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
            let cell = tableView.dequeueReusableCell(withIdentifier: "PlayerStatCell", for: indexPath) as! PlayerStatCell
            
            let stats = tableView == team1View ? team1PlayerStats[indexPath.row] : team2PlayerStats[indexPath.row]
            cell.configure(with: stats)
            
            return cell
        }

    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "tocompare",
           let destinationVC = segue.destination as? ComparePlayersViewController {
            destinationVC.currentMatchId = currentMatchId
        } else if segue.identifier == "toScorefromPlayer",
            let destinationVC = segue.destination as? ScoreViewController {
            destinationVC.currentMatchId = currentMatchId
            destinationVC.team1Name = team1Name
            destinationVC.team2Name = team2Name
        } else if segue.identifier == "toActionFromPlayerStat",
            let destinationVC = segue.destination as? ActionViewController {
            destinationVC.currentMatchId = currentMatchId
            destinationVC.team1Name = team1Name
            destinationVC.team2Name = team2Name
        }
    }
        // MARK: - Helper Methods
        private func showAlert(message: String) {
            let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
            alert.addAction(UIAlertAction(title: "OK", style: .default))
            present(alert, animated: true)
        }
    }
