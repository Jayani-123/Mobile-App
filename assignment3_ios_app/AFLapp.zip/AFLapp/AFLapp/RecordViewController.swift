//
//  RecordViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 13/5/2025.
//

import UIKit
import Firebase
import FirebaseFirestore

class RecordViewController: UIViewController {
    
    
    // MARK: - Outlets

    @IBOutlet weak var scoreButton: UIButton!
    @IBOutlet weak var playerButton: UIButton!
    
    @IBOutlet weak var q1Button: UIButton!
    @IBOutlet weak var q2Button: UIButton!
    @IBOutlet weak var q3Button: UIButton!
    @IBOutlet weak var q4Button: UIButton!
    
    @IBOutlet weak var gameTimeLabel: UILabel!
    @IBOutlet weak var timeDisplayLabel: UILabel!
    
    @IBOutlet weak var playButton: UIButton!
    @IBOutlet weak var pauseButton: UIButton!
    @IBOutlet weak var stopButton: UIButton!
    
    
    @IBOutlet weak var progressView: UIProgressView!
    
    @IBOutlet weak var kickButton: UIButton!
    @IBOutlet weak var handballButton: UIButton!
    @IBOutlet weak var markButton: UIButton!
    @IBOutlet weak var tackleButton: UIButton!
    @IBOutlet weak var goalButton: UIButton!
    @IBOutlet weak var behindButton: UIButton!
    
    @IBOutlet weak var team1View: UIView!
    @IBOutlet weak var team2View: UIView!
    private var team1Name: String = "Team 1" // Store actual team name
    private var team2Name: String = "Team 2" // Store actual team name
    
    @IBOutlet weak var team1Label: UILabel!
    @IBOutlet weak var team2Label: UILabel!
    
    private var timer: Timer?
    private var elapsedSeconds: Int = 0 // Total game time
    private var quarterElapsedSeconds: Int = 0 // Time within current quarter
    private var isTimerRunning: Bool = false
    private var currentQuarter: Int = 1 // 1 = Q1, 2 = Q2, 3 = Q3, 4 = Q4
    private let quarterDuration: Int = 1200 // 20 minutes in seconds
    var currentMatchId: String?
    private var team1Players: [Player] = []
    private var team2Players: [Player] = []
    
    private var team1Buttons: [UIButton] = [] // To store Team 1 player buttons
    private var team2Buttons: [UIButton] = [] // To store Team 2 player buttons
    private var selectedPlayer: Player? // Currently selected player
    private var selectedTeam: String? // "team1" or "team2"
    private var matchActions: [MatchAction] = [] // Log of all match actions
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        // Set up navigation bar
        navigationItem.title = "Record Match"
        navigationController?.setNavigationBarHidden(false, animated: false)
        
        // Style progress view
        progressView.progressTintColor = .blue
        progressView.trackTintColor = .lightGray
        progressView.progress = 0.0
        
        // Set initial game time
        gameTimeLabel.text = "Game Time"
        updateTimeDisplay()
        
        // Style quarter buttons
        updateQuarterButtons()
        
        // Style action buttons
        styleActionButton(kickButton, isActive: true)
        styleActionButton(handballButton, isActive: true)
        styleActionButton(markButton, isActive: true)
        styleActionButton(tackleButton, isActive: true)
        styleActionButton(goalButton, isActive: false)
        styleActionButton(behindButton, isActive: false)
        
        // Disable goal and behind buttons initially
        goalButton.isEnabled = false
        behindButton.isEnabled = false
        
        playButton.setImage(UIImage(systemName: "play.fill"), for: .normal)
        pauseButton.setImage(UIImage(systemName: "pause.fill"), for: .normal)
        stopButton.setImage(UIImage(systemName: "stop.fill"), for: .normal)
        
        // Add targets to action buttons
        kickButton.addTarget(self, action: #selector(actionButtonTapped(_:)), for: .touchUpInside)
        handballButton.addTarget(self, action: #selector(actionButtonTapped(_:)), for: .touchUpInside)
        markButton.addTarget(self, action: #selector(actionButtonTapped(_:)), for: .touchUpInside)
        tackleButton.addTarget(self, action: #selector(actionButtonTapped(_:)), for: .touchUpInside)
        goalButton.addTarget(self, action: #selector(actionButtonTapped(_:)), for: .touchUpInside)
        behindButton.addTarget(self, action: #selector(actionButtonTapped(_:)), for: .touchUpInside)
        
        // Load team names and players
        loadTeamNames()
        loadTeam1Players()
        loadTeam2Players()
        
    }
    
    deinit {
        timer?.invalidate()
    }
    
    // MARK: - Styling Methods
    private func styleQuarterButton(_ button: UIButton, isSelected: Bool) {
        button.layer.cornerRadius = 4
        button.backgroundColor = isSelected ? .white : .lightGray
        button.setTitleColor(isSelected ? .black : .gray, for: .normal)
    }
    
    private func styleActionButton(_ button: UIButton, isActive: Bool) {
            button.layer.cornerRadius = 10
            button.backgroundColor = isActive ? UIColor.blue : UIColor.lightGray
            button.setTitleColor(.white, for: .normal)
            button.isEnabled = isActive
        }
    
    private func updateQuarterButtons() {
        styleQuarterButton(q1Button, isSelected: currentQuarter == 1)
        styleQuarterButton(q2Button, isSelected: currentQuarter == 2)
        styleQuarterButton(q3Button, isSelected: currentQuarter == 3)
        styleQuarterButton(q4Button, isSelected: currentQuarter == 4)
    }
    
    // MARK: - Timer Methods
    private func updateTimeDisplay() {
        let minutes = quarterElapsedSeconds / 60 // Display only current quarter time
        let seconds = quarterElapsedSeconds % 60
        timeDisplayLabel.text = String(format: "%02d:%02d", minutes, seconds)
    }
    
    private func getQuarterTime() -> String {
        let minutes = quarterElapsedSeconds / 60
        let seconds = quarterElapsedSeconds % 60
        return String(format: "%02d:%02d", minutes, seconds)
    }
    
    private func updateProgressView() {
        let progress = Float(quarterElapsedSeconds) / Float(quarterDuration)
        progressView.progress = min(max(progress, 0.0), 1.0) // Ensure progress stays between 0 and 1
    }
    
    @objc private func timerFired() {
        quarterElapsedSeconds += 1
        elapsedSeconds += 1
        updateTimeDisplay()
        updateProgressView()
        
        // Check if the quarter has ended (20 minutes)
        if quarterElapsedSeconds >= quarterDuration {
            timer?.invalidate()
            isTimerRunning = false
            showQuarterEndAlert()
        }
    }
    

    private func startNextQuarter() {
        if currentQuarter < 4 {
            currentQuarter += 1
            quarterElapsedSeconds = 0 // Reset quarter time
            updateQuarterButtons()
            updateTimeDisplay() // Update to show 00:00
            updateProgressView() // Reset progress to 0
            if isTimerRunning {
                timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerFired), userInfo: nil, repeats: true)
            }
        } else {
            showMatchEndAlert()
        }
    }
    // MARK: - Actions
    @IBAction func playButtonTapped(_ sender: UIButton) {
        
        if !isTimerRunning {
            timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(timerFired), userInfo: nil, repeats: true)
            isTimerRunning = true
        }
    }
    
    
    
    @IBAction func pauseButtonTapped(_ sender: UIButton) {
        if isTimerRunning {
            timer?.invalidate()
            isTimerRunning = false
        }
    }
    
    
    @IBAction func stopButtonTapped(_ sender: UIButton) {
        timer?.invalidate()
        isTimerRunning = false
        showQuarterSelectionAlert()
    }
    
    // MARK: - Update Match Status
    private func updateMatchFinishedStatus() {
        guard let matchId = currentMatchId else {
            print("Error: currentMatchId is nil")
            showAlert(message: "Error: Match ID is missing")
            return
        }
        
        let db = Firestore.firestore()
        db.collection("match").document(matchId).updateData([
            "isFinished": true
        ]) { [weak self] error in
            guard let self = self else { return }
            if let error = error {
                print("Error updating match status: \(error.localizedDescription)")
                self.showAlert(message: "Failed to update match status: \(error.localizedDescription)")
            } else {
                print("Match \(matchId) marked as finished in Firestore")
            }
        }
    }

    // Modified showQuarterEndAlert
    private func showQuarterEndAlert() {
        let alert = UIAlertController(title: "Quarter Ended", message: "Quarter \(currentQuarter) has ended after 20 minutes. Start the next quarter?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "Start Next Quarter", style: .default) { [weak self] _ in
            guard let self = self else { return }
            self.startNextQuarter()
        })
        
        alert.addAction(UIAlertAction(title: "End Match", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.timer?.invalidate()
            self.isTimerRunning = false
            self.elapsedSeconds = 0
            self.quarterElapsedSeconds = 0
            self.currentQuarter = 1
            self.updateQuarterButtons()
            self.updateTimeDisplay()
            self.updateProgressView()
            
            // Update Firestore
            self.updateMatchFinishedStatus()
        })
        
        present(alert, animated: true, completion: nil)
    }

    // Modified showMatchEndAlert
    private func showMatchEndAlert() {
        let alert = UIAlertController(title: "Match Ended", message: "All quarters have been completed. End the match?", preferredStyle: .alert)
        
        alert.addAction(UIAlertAction(title: "End Match", style: .default) { [weak self] _ in
            guard let self = self else { return }
            self.timer?.invalidate()
            self.isTimerRunning = false
            self.elapsedSeconds = 0
            self.quarterElapsedSeconds = 0
            self.currentQuarter = 1
            self.updateQuarterButtons()
            self.updateTimeDisplay()
            self.updateProgressView()
            
            // Update Firestore
            self.updateMatchFinishedStatus()
        })
        
        present(alert, animated: true, completion: nil)
    }

    // Modified showQuarterSelectionAlert
    private func showQuarterSelectionAlert() {
        let alert = UIAlertController(title: "Select Next Quarter", message: "Choose the next quarter to continue or end the match.", preferredStyle: .actionSheet)
        
        if currentQuarter < 4 {
            alert.addAction(UIAlertAction(title: "Quarter \(currentQuarter + 1)", style: .default) { [weak self] _ in
                guard let self = self else { return }
                self.startNextQuarter()
                if self.isTimerRunning {
                    self.timer = Timer.scheduledTimer(timeInterval: 1.0, target: self, selector: #selector(self.timerFired), userInfo: nil, repeats: true)
                }
            })
        }
        
        alert.addAction(UIAlertAction(title: "End Match", style: .destructive) { [weak self] _ in
            guard let self = self else { return }
            self.timer?.invalidate()
            self.isTimerRunning = false
            self.elapsedSeconds = 0
            self.quarterElapsedSeconds = 0
            self.currentQuarter = 1
            self.updateQuarterButtons()
            self.updateTimeDisplay()
            self.updateProgressView()
            
            // Update Firestore
            self.updateMatchFinishedStatus()
        })
        
        alert.addAction(UIAlertAction(title: "Cancel", style: .cancel, handler: nil))
        
        // Present action sheet on iPad
        if let popoverController = alert.popoverPresentationController {
            popoverController.sourceView = stopButton
            popoverController.sourceRect = stopButton.bounds
        }
        
        present(alert, animated: true, completion: nil)
    }
    
    @IBAction func quarterButtonTapped(_ sender: UIButton) {
        if let newQuarter = [q1Button, q2Button, q3Button, q4Button].firstIndex(of: sender) {
            if newQuarter + 1 <= currentQuarter {
                currentQuarter = newQuarter + 1
                quarterElapsedSeconds = 0
                updateQuarterButtons()
                updateTimeDisplay()
                updateProgressView()
            }
        }
        
    }
    
    @objc private func playerTapped(_ sender: UIButton) {
            if let index = team1Buttons.firstIndex(of: sender) {
                selectedPlayer = team1Players[index]
                selectedTeam = "team1"
                // Update button states when a player is selected
                updateActionButtonStates()
            } else if let index = team2Buttons.firstIndex(of: sender) {
                selectedPlayer = team2Players[index]
                selectedTeam = "team2"
                // Update button states when a player is selected
                updateActionButtonStates()
            }
        }
    
    private func updateActionButtonStates() {
            guard let lastAction = matchActions.last, let selectedTeam = selectedTeam else {
                // No actions recorded or no team selected, disable both buttons
                goalButton.isEnabled = false
                behindButton.isEnabled = false
                styleActionButton(goalButton, isActive: false)
                styleActionButton(behindButton, isActive: false)
                return
            }

            let lastActionLowercased = lastAction.action.lowercased()
            let lastActionTeamName = lastAction.teamName
            let currentTeamName = selectedTeam == "team1" ? team1Name : team2Name

            // Enable goal button only if last action was a kick by the same team
            if lastActionLowercased == "kick" && lastActionTeamName == currentTeamName {
                goalButton.isEnabled = true
                styleActionButton(goalButton, isActive: true)
            } else {
                goalButton.isEnabled = false
                styleActionButton(goalButton, isActive: false)
            }

            // Enable behind button if last action was a kick or handball by the same team
            if ["kick", "handball"].contains(lastActionLowercased) && lastActionTeamName == currentTeamName {
                behindButton.isEnabled = true
                styleActionButton(behindButton, isActive: true)
            } else {
                behindButton.isEnabled = false
                styleActionButton(behindButton, isActive: false)
            }
        }

    @objc private func actionButtonTapped(_ sender: UIButton) {
            // Check if the play button has been pressed (timer is running)
            guard isTimerRunning else {
                showAlert(message: "Please start the match by pressing the play button.")
                return
            }

            guard let action = sender.titleLabel?.text?.lowercased() else { return }
            
            // Ensure a player is selected for player-specific actions
            if ["kick", "handball", "mark", "tackle", "goal", "behind"].contains(action) {
                guard let player = selectedPlayer, let team = selectedTeam else {
                    showAlert(message: "Please select a player first.")
                    return
                }
                
                // Determine the team name based on selected team
                let teamName = team == "team1" ? team1Name : team2Name
                
                // Validate goal and behind actions based on previous action
                if action == "goal" {
                    guard let lastAction = matchActions.last, lastAction.action.lowercased() == "kick", lastAction.teamName == teamName else {
                        showAlert(message: "A goal can only be recorded after a kick action by the same team.")
                        return
                    }
                } else if action == "behind" {
                    guard let lastAction = matchActions.last, ["kick", "handball"].contains(lastAction.action.lowercased()), lastAction.teamName == teamName else {
                        showAlert(message: "A behind can only be recorded after a kick or handball action by the same team.")
                        return
                    }
                }
                
                // Record the action
                recordMatchAction(action.capitalized, player: player, teamName: teamName)
                // Show popup message for successful action
                showActionConfirmationPopup(action: action.capitalized, playerName: player.name, teamName: teamName)
                // Update button states after recording the action
                updateActionButtonStates()
            }
        }
    
    // MARK: - Show Action Confirmation Popup
    private func showActionConfirmationPopup(action: String, playerName: String, teamName: String) {
        let message = "\(action) recorded for \(playerName) (\(teamName))"
        let alert = UIAlertController(title: "Success", message: message, preferredStyle: .alert)
        
        // Auto-dismiss after 0.1 seconds
        DispatchQueue.main.asyncAfter(deadline: .now() + 0.1) {
            alert.dismiss(animated: true, completion: nil)
        }
        
        present(alert, animated: true, completion: nil)
    }

    // MARK: - Match Action Methods
    private func recordMatchAction(_ action: String, player: Player?, teamName: String?) {
        // Create the match action with quarter time and team name
        let matchAction = MatchAction(
            action: action,
            playerId: player?.documentID ?? "N/A",
            playerName: player?.name ?? "N/A",
            playerNumber: player?.number ?? "N/A",
            teamName: player?.team ?? "N/A",
            timestamp: Date(),
            quarter: currentQuarter,
            quarterTime: getQuarterTime()
        )
        matchActions.append(matchAction)
        print("Action Recorded: \(action) by \(player?.name ?? "N/A") (\(teamName ?? "N/A")) at \(matchAction.quarterTime) in Quarter \(currentQuarter)")
        
        // Save to Firestore
        guard let matchId = currentMatchId else { return }
        let db = Firestore.firestore()
        let actionData: [String: Any] = [
            "action": action,
            "playerName": player?.name ?? "N/A",
            "playerNumber": player?.number ?? "N/A",
            "playerId": player?.documentID ?? "N/A",
            "teamName": teamName ?? "N/A",
            "timestamp": Timestamp(date: matchAction.timestamp),
            "quarter": currentQuarter,
            "quarterTime": matchAction.quarterTime
        ]
        db.collection("match").document(matchId).collection("actions").addDocument(data: actionData) { error in
            if let error = error {
                print("Error saving action to Firestore: \(error)")
            }
        }
    }
    
    // MARK: - Firestore Methods
    private func loadTeamNames() {
        guard let matchId = currentMatchId else { return }
        let db = Firestore.firestore()
        db.collection("match").document(matchId).getDocument { [weak self] (document, error) in
            guard let self = self, let document = document, document.exists, error == nil else {
                self?.showAlert(message: "Error loading team names")
                return
            }
            self.team1Name = document.get("team1") as? String ?? "Team 1"
            self.team2Name = document.get("team2") as? String ?? "Team 2"
            DispatchQueue.main.async {
                self.team1Label.text = self.team1Name
                self.team2Label.text = self.team2Name
            }
        }
    }
    
    private func loadTeam1Players() {
        guard let matchId = currentMatchId else { return }
        let db = Firestore.firestore()
        db.collection("match").document(matchId).collection("team1players").getDocuments { [weak self] (snapshot, error) in
            guard let self = self, let snapshot = snapshot, error == nil else {
                self?.showAlert(message: "Error loading team 1 players")
                return
            }
            self.team1Players = snapshot.documents.compactMap { doc in
                try? doc.data(as: Player.self)
            }
            DispatchQueue.main.async {
                self.displayPlayersInTeamView()
            }
        }
    }
    
    private func loadTeam2Players() {
        guard let matchId = currentMatchId else { return }
        let db = Firestore.firestore()
        db.collection("match").document(matchId).collection("team2players").getDocuments { [weak self] (snapshot, error) in
            guard let self = self, let snapshot = snapshot, error == nil else {
                self?.showAlert(message: "Error loading team 2 players")
                return
            }
            self.team2Players = snapshot.documents.compactMap { doc in
                try? doc.data(as: Player.self)
            }
            DispatchQueue.main.async {
                self.displayPlayersInTeamView()
            }
        }
    }
    
    private func displayPlayersInTeamView() {
        // Clear existing player buttons (if any)
        team1View.subviews.filter { $0 != team1Label }.forEach { $0.removeFromSuperview() }
        team2View.subviews.filter { $0 != team2Label }.forEach { $0.removeFromSuperview() }
        team1Buttons.removeAll()
        team2Buttons.removeAll()
        
        // Display Team 1 players as buttons
        var lastButton: UIButton? = nil
        for (index, player) in team1Players.enumerated() {
            let playerButton = UIButton(type: .system)
            playerButton.translatesAutoresizingMaskIntoConstraints = false
            playerButton.setTitle("\(player.number). \(player.name)", for: .normal)
            playerButton.addTarget(self, action: #selector(playerTapped(_:)), for: .touchUpInside)
            playerButton.tag = index
            stylePlayerButton(playerButton)
            team1View.addSubview(playerButton)
            team1Buttons.append(playerButton)
            
            NSLayoutConstraint.activate([
                playerButton.leadingAnchor.constraint(equalTo: team1View.leadingAnchor, constant: 8),
                playerButton.trailingAnchor.constraint(equalTo: team1View.trailingAnchor, constant: -8),
                playerButton.topAnchor.constraint(equalTo: lastButton?.bottomAnchor ?? team1Label.bottomAnchor, constant: 8)
            ])
            
            lastButton = playerButton
        }
        
        // Display Team 2 players as buttons
        lastButton = nil
        for (index, player) in team2Players.enumerated() {
            let playerButton = UIButton(type: .system)
            playerButton.translatesAutoresizingMaskIntoConstraints = false
            playerButton.setTitle("\(player.number). \(player.name)", for: .normal)
            playerButton.addTarget(self, action: #selector(playerTapped(_:)), for: .touchUpInside)
            playerButton.tag = index
            stylePlayerButton(playerButton)
            team2View.addSubview(playerButton)
            team2Buttons.append(playerButton)
            
            NSLayoutConstraint.activate([
                playerButton.leadingAnchor.constraint(equalTo: team2View.leadingAnchor, constant: 8),
                playerButton.trailingAnchor.constraint(equalTo: team2View.trailingAnchor, constant: -8),
                playerButton.topAnchor.constraint(equalTo: lastButton?.bottomAnchor ?? team2Label.bottomAnchor, constant: 8)
            ])
            
            lastButton = playerButton
        }
    }
    
    private func stylePlayerButton(_ button: UIButton) {
        button.layer.cornerRadius = 8
        button.backgroundColor = .systemBlue
        button.setTitleColor(.white, for: .normal)
        button.titleLabel?.font = .systemFont(ofSize: 14, weight: .medium)
        
        // Add "+" icon
        var config = UIButton.Configuration.filled()
        config.image = UIImage(systemName: "plus")
        config.imagePlacement = .leading // Icon before the title
        config.imagePadding = 8 // Space between icon and title
        config.baseBackgroundColor = .systemBlue
        config.baseForegroundColor = .white
        config.titleAlignment = .leading // Align title to the left
        button.configuration = config
    }
    
    private func showAlert(message: String) {
        let alert = UIAlertController(title: nil, message: message, preferredStyle: .alert)
        alert.addAction(UIAlertAction(title: "OK", style: .default, handler: nil))
        present(alert, animated: true) {
            DispatchQueue.main.asyncAfter(deadline: .now() + 2.0) {
                alert.dismiss(animated: true, completion: nil)
            }
        }
    }
    

    
    // MARK: - Prepare for Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toactionList",
           let destinationVC = segue.destination as? ActionViewController {
            destinationVC.currentMatchId = currentMatchId
        } else if segue.identifier == "toMatchSummry",
                  let destinationVC = segue.destination as? ScoreViewController {
            destinationVC.currentMatchId = currentMatchId
            destinationVC.team1Name = team1Name
            destinationVC.team2Name = team2Name
        } else if segue.identifier == "toPlayerStat",
                  let destinationVC = segue.destination as? PlayerStatViewController {
            destinationVC.currentMatchId = currentMatchId
            destinationVC.team1Name = team1Name
            destinationVC.team2Name = team2Name
            
            
        }
    }
    
    

    
}
