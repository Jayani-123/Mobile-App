//
//  PlayerStatCell.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 18/5/2025.
//

import UIKit

class PlayerStatCell: UITableViewCell {
    
    
    
    
    @IBOutlet weak var nameLabel: UILabel!
        @IBOutlet weak var numberLabel: UILabel!
        @IBOutlet weak var goalsLabel: UILabel!
        @IBOutlet weak var behindsLabel: UILabel!
        @IBOutlet weak var kicksLabel: UILabel!
        @IBOutlet weak var handballsLabel: UILabel!
        @IBOutlet weak var marksLabel: UILabel!
        @IBOutlet weak var tacklesLabel: UILabel!
        
        func configure(with stats: PlayerStats) {
            nameLabel.text = "\(stats.name) "
            numberLabel.text = "\(stats.number)"
            goalsLabel.text = "\(stats.goals)"
            behindsLabel.text = "\(stats.behinds)"
            kicksLabel.text = "\(stats.kicks)"
            handballsLabel.text = "\(stats.handballs)"
            marksLabel.text = "\(stats.marks)"
            tacklesLabel.text = "\(stats.tackles)"
        }
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
