//
//  WormGraphView.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 20/5/2025.
//

import UIKit

class WormGraphView: UIView {
    
    var team1Scores: [(time: TimeInterval, score: Int)] = []
    var team2Scores: [(time: TimeInterval, score: Int)] = []
    var team1Name: String = "Team 1"
    var team2Name: String = "Team 2"
    var quarters: [TimeInterval] = []
    
    private let team1Color = UIColor.systemBlue
    private let team2Color = UIColor.systemRed
    private let gridColor = UIColor.lightGray.withAlphaComponent(0.3)
    private let axisColor = UIColor.black
    private let padding: CGFloat = 40.0
    
    override func draw(_ rect: CGRect) {
        guard team1Scores.count > 1 || team2Scores.count > 1 else { return }
        guard let context = UIGraphicsGetCurrentContext() else { return }
        
        let graphWidth = rect.width - 2 * padding
        let graphHeight = rect.height - 2 * padding
        
        let allTimes = (team1Scores + team2Scores).map { $0.time }
        guard let minTime = allTimes.min(), let maxTime = allTimes.max(), maxTime > minTime else { return }
        
        let maxScore = max(
            team1Scores.map { $0.score }.max() ?? 0,
            team2Scores.map { $0.score }.max() ?? 0
        ) + 10
        
        guard maxScore > 0 else { return }
        
        func xPosition(time: TimeInterval) -> CGFloat {
            padding + CGFloat((time - minTime) / (maxTime - minTime)) * graphWidth
        }
        
        func yPosition(score: Int) -> CGFloat {
            padding + graphHeight - (CGFloat(score) / CGFloat(maxScore) * graphHeight)
        }
        
        // Draw grid lines
        context.setStrokeColor(gridColor.cgColor)
        context.setLineWidth(0.5)
        
        let scoreLines = 5
        for i in 0...scoreLines {
            let score = maxScore * i / scoreLines
            let y = yPosition(score: score)
            context.move(to: CGPoint(x: padding, y: y))
            context.addLine(to: CGPoint(x: padding + graphWidth, y: y))
        }
        
        for quarterTime in quarters {
            let x = xPosition(time: quarterTime)
            context.move(to: CGPoint(x: x, y: padding))
            context.addLine(to: CGPoint(x: x, y: padding + graphHeight))
        }
        context.strokePath()
        
        // Draw axes
        context.setStrokeColor(axisColor.cgColor)
        context.setLineWidth(1.0)
        context.move(to: CGPoint(x: padding, y: padding))
        context.addLine(to: CGPoint(x: padding, y: padding + graphHeight))
        context.move(to: CGPoint(x: padding, y: padding + graphHeight))
        context.addLine(to: CGPoint(x: padding + graphWidth, y: padding + graphHeight))
        context.strokePath()
        
        // Draw Y-axis labels
        let labelFont = UIFont.systemFont(ofSize: 10)
        let labelColor = UIColor.black
        
        for i in 0...scoreLines {
            let score = maxScore * i / scoreLines
            let y = yPosition(score: score)
            let label = "\(score)" as NSString
            label.draw(at: CGPoint(x: 5, y: y - 6), withAttributes: [
                .font: labelFont,
                .foregroundColor: labelColor
            ])
        }
        
        // Draw X-axis quarter labels
        for (index, quarterTime) in quarters.enumerated() {
            let x = xPosition(time: quarterTime)
            let label = "Q\(index + 1)" as NSString
            label.draw(at: CGPoint(x: x - 10, y: padding + graphHeight + 5), withAttributes: [
                .font: labelFont,
                .foregroundColor: labelColor
            ])
        }
        
        // Draw team names with their colors at top left/right
        let team1Label = "\(team1Name)" as NSString
        team1Label.draw(at: CGPoint(x: padding, y: 5), withAttributes: [
            .font: UIFont.boldSystemFont(ofSize: 14),
            .foregroundColor: team1Color
        ])
        
        let team2Label = "\(team2Name)" as NSString
        let team2LabelSize = team2Label.size(withAttributes: [.font: UIFont.boldSystemFont(ofSize: 14)])
        team2Label.draw(at: CGPoint(x: rect.width - padding - team2LabelSize.width, y: 5), withAttributes: [
            .font: UIFont.boldSystemFont(ofSize: 14),
            .foregroundColor: team2Color
        ])
        
        // Draw team 1 line
        context.setStrokeColor(team1Color.cgColor)
        context.setLineWidth(3.0)
        context.setLineJoin(.round)
        
        context.beginPath()
        for (i, point) in team1Scores.enumerated() {
            let x = xPosition(time: point.time)
            let y = yPosition(score: point.score)
            if i == 0 {
                context.move(to: CGPoint(x: x, y: y))
            } else {
                context.addLine(to: CGPoint(x: x, y: y))
            }
        }
        context.strokePath()
        
        // Draw team 2 line
        context.setStrokeColor(team2Color.cgColor)
        context.setLineWidth(3.0)
        context.setLineJoin(.round)
        
        context.beginPath()
        for (i, point) in team2Scores.enumerated() {
            let x = xPosition(time: point.time)
            let y = yPosition(score: point.score)
            if i == 0 {
                context.move(to: CGPoint(x: x, y: y))
            } else {
                context.addLine(to: CGPoint(x: x, y: y))
            }
        }
        context.strokePath()
    }
}

