//
//  TeamRankViewController.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 19/5/2025.
//

    import UIKit
    import Firebase
    import FirebaseFirestore
class TeamRankViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
        
        // Table view
       
        @IBOutlet weak var teamRankTable: UITableView!
        
        // Firestore instance
            private let db = Firestore.firestore()
            
            // Array to store teams
            private var teams: [Team] = []
            
            override func viewDidLoad() {
                super.viewDidLoad()

                
                // Register delegate and dataSource
                teamRankTable.delegate = self
                teamRankTable.dataSource = self
                
                // Load team data
                loadTeamData()
            }
            
            // MARK: - Fetch Team Data from Firestore
            private func loadTeamData() {
                db.collection("match").getDocuments { (matchSnapshot, error) in
                    if let error = error {
                        print("Error fetching matches: \(error.localizedDescription)")
                        self.showAlert(message: "Failed to load matches.")
                        return
                    }
                    
                    guard let matchDocs = matchSnapshot?.documents else {
                        self.showAlert(message: "No matches found.")
                        return
                    }
                    
                    var teamPoints: [String: Int] = [:] // Tracks points (4 for win, 2 for draw, 0 for loss)
                    var teamStats: [String: (goals: Int, behinds: Int, score: Int)] = [:] // Tracks goals, behinds, and score
                    
                    let dispatchGroup = DispatchGroup()
                    
                    for matchDoc in matchDocs {
                        let matchId = matchDoc.documentID
                        let actionsRef = self.db.collection("match").document(matchId).collection("actions")
                        dispatchGroup.enter()
                        
                        actionsRef.getDocuments { (actionSnapshot, error) in
                            if let error = error {
                                print("Error fetching actions for match \(matchId): \(error.localizedDescription)")
                                dispatchGroup.leave()
                                return
                            }
                            
                            guard let actionDocs = actionSnapshot?.documents else {
                                dispatchGroup.leave()
                                return
                            }
                            
                            // Group actions by team
                            let teamActions = Dictionary(grouping: actionDocs, by: { $0.get("teamName") as? String ?? "" })
                            
                            // Ensure there are exactly two teams in the match
                            let teamNames = teamActions.keys.filter { !$0.isEmpty }
                            guard teamNames.count == 2 else {
                                print("Match \(matchId) does not have exactly two teams")
                                dispatchGroup.leave()
                                return
                            }
                            
                            let team1Name = teamNames[0]
                            let team2Name = teamNames[1]
                            
                            // Calculate scores for both teams
                            let team1Actions = teamActions[team1Name] ?? []
                            let team2Actions = teamActions[team2Name] ?? []
                            
                            let team1Goals = team1Actions.filter { $0.get("action") as? String == "Goal" }.count
                            let team1Behinds = team1Actions.filter { $0.get("action") as? String == "Behind" }.count
                            let team1Score = (team1Goals * 6) + team1Behinds
                            
                            let team2Goals = team2Actions.filter { $0.get("action") as? String == "Goal" }.count
                            let team2Behinds = team2Actions.filter { $0.get("action") as? String == "Behind" }.count
                            let team2Score = (team2Goals * 6) + team2Behinds
                            
                            // Update team stats
                            if teamStats[team1Name] == nil {
                                teamStats[team1Name] = (goals: 0, behinds: 0, score: 0)
                            }
                            if teamStats[team2Name] == nil {
                                teamStats[team2Name] = (goals: 0, behinds: 0, score: 0)
                            }
                            
                            teamStats[team1Name]!.goals += team1Goals
                            teamStats[team1Name]!.behinds += team1Behinds
                            teamStats[team1Name]!.score += team1Score
                            
                            teamStats[team2Name]!.goals += team2Goals
                            teamStats[team2Name]!.behinds += team2Behinds
                            teamStats[team2Name]!.score += team2Score
                            
                            // Determine match result and assign points
                            if team1Score > team2Score {
                                teamPoints[team1Name, default: 0] += 4 // Team 1 wins
                                teamPoints[team2Name, default: 0] += 0 // Team 2 loses
                            } else if team2Score > team1Score {
                                teamPoints[team2Name, default: 0] += 4 // Team 2 wins
                                teamPoints[team1Name, default: 0] += 0 // Team 1 loses
                            } else {
                                teamPoints[team1Name, default: 0] += 2 // Draw
                                teamPoints[team2Name, default: 0] += 2 // Draw
                            }
                            
                            dispatchGroup.leave()
                        }
                    }
                    
                    dispatchGroup.notify(queue: .main) {
                        // Create Team objects
                        self.teams = teamStats.map { (teamName, stats) in
                            Team(
                                name: teamName,
                                goals: stats.goals,
                                behinds: stats.behinds,
                                score: stats.score,
                                points: teamPoints[teamName] ?? 0
                            )
                        }
                        
                        // Sort teams by points, then by score
                        self.teams.sort(by: <)
                        self.teamRankTable.reloadData()
                    }
                }
            }
            
            // MARK: - UITableViewDataSource
            func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
                return teams.count
            }
            
            func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
                guard let cell = tableView.dequeueReusableCell(withIdentifier: "TeamRankCell", for: indexPath) as? TeamRankCell else {
                    return UITableViewCell()
                }
                let team = teams[indexPath.row]
                
                cell.rankLabel.text = "\(indexPath.row + 1)"
                cell.nameLabel.text = team.name
                cell.scoreLabel.text = "\(team.points) (Score: \(team.score))"
                
                return cell
            }
            
            // MARK: - Show Alert
            private func showAlert(message: String) {
                let alert = UIAlertController(title: "Error", message: message, preferredStyle: .alert)
                alert.addAction(UIAlertAction(title: "OK", style: .default))
                present(alert, animated: true)
            }
        }
