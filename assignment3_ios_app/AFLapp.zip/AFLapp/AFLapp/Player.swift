//
//  Player.swift
//  AFLapp
//
//  Created by Jayani Madusha Edirisinghe on 7/5/2025.
//

import Firebase
import FirebaseFirestore

struct Player: Codable {
    var documentID: String?
    let name: String
    let number: String
    let position: String
    let team: String
    let age: String
    let height: String
    let imageBase64: String?

}
